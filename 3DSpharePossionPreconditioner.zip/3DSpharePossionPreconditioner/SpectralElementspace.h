#ifndef SpectralElementspace
#define SpectralElementspace

#include "FEMSpace.h"

#define PI 4.0*atan(1.0)

/***************************************
Transpose the Cartier coordinate (x,y) to 
elliptical coordinate(r,\theta) !-)
***************************************/ 


class SpectralElementSpace : public CGFEMSpace{

public:
    SpectralElementSpace(){
    	
	}

    ~SpectralElementSpace(){
    	//delete MoveVector;
	}
	
	
	//void cartToellip(double x, double y, double &r, double &theta);
	/*********************************
	Transpose the element to refrence element by Gordon-Hall Tran.
	*********************************/
    virtual Vector mapping(INT i, Vector &lambda);

    virtual DOUBLE jacobi(INT i, Vector &lambda);

    virtual Matrix JM(INT i, Vector &lambda);

    virtual Matrix JMIT(INT i, Vector &lambda);
    
    Matrix TransformedLaplace(INT i, Vector &lambda);
    PMatrix* DiffJMIT(INT i, Vector &lambda);

    // compute L2 error of the i-th solution with the exact function f
//    virtual DOUBLE L2Error(Coefficient *f, Vector &uh);
//    DOUBLE  L2ErrorOfGrad(Coefficient *f, Vector &uh);

};

#endif // SPECTRALELEMENTSPACE_H
