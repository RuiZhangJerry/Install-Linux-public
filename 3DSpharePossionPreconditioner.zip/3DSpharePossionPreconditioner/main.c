#include "SE_Variabal_Coeff_Poisson_Precondition_test.h"

int main(){
    Grid3D *grid=new Grid3D(); 
	//Grid3D *gridref=new Grid3D();                 // construct grid
    int n=5;

//    grid->readGrid("cubicmesh16x16.dat", 6);
//    grid->readGrid("cubicmesh8x8.dat", 6);
    //grid->readGrid("cubicmesh1x1x1.dat", 6);
//	grid->readGrid("cubicmesh4x4.dat", 6);
	//grid->readGrid("cubicmesh.dat", 6);
	grid->readGrid("mesh.dat", 6);

   // Cubic mesh
   // construct quadrature and trial function
   Quadrature *quad=new Quadrature(CUBE, GAUSS_LOBATTAO_QUADRATURE);
   quad->permuteData(n);
   LAGRANGE_3D_CUBE* trial=new LAGRANGE_3D_CUBE(n-1);
   
	DOUBLE glp[n], wts[n];
	Quadrature::LegendreGaussLobatto(n, glp, wts);
	Vector coord(n);
	coord=glp;
	trial->setNodePointCoord(coord);
	trial->computeCoefficient();


   SpectralElementSpace *femspace=new SpectralElementSpace();  // construct space
   femspace->setGrid(grid);

   femspace->setQuadrature(quad);          // set quadraturen and trial function for space
   femspace->setNTrialFunction(1);
   femspace->setNTestFunction(1);
   femspace->setTestFunction(trial, 0);
   femspace->setTrialFunction(trial, 0);

   femspace->formSpace();                  // prepare space
   
//   SpectralElementSpaceRef *refspace=new SpectralElementSpaceRef();
//   refspace->setGrid(gridref);
//   refspace->setQuadrature(quad);          // set quadraturen and trial function for space
//   refspace->setNTrialFunction(1);
//   refspace->setNTestFunction(1);
//   refspace->setTestFunction(trial, 0);
//   refspace->setTrialFunction(trial, 0);
//
//   refspace->formSpace();                  // prepare space

   cout<<"Number of vertexes: "<<grid->getNVertex()<<endl;
   cout<<"Number of edges: "<<grid->getNEdge()<<endl;
   cout<<"Number of faces: "<<grid->getNFace()<<endl;
   cout<<"Number of elements: "<<grid->getNElement()<<endl;
   cout<<"eledof= "<<trial->degreeOfFreedom()<<endl;

   cout<<femspace->degreeOfFreedom()<<endl;
//   Vector lambda(3);             // construct FEM problem
//   lambda[0]=1.0;
//   Matrix** P=femspace->DiffJMIT(0,lambda);
//   cout<<*P[1]<<endl;
   pSEVCP problem=new SE_Variabal_Coeff_Poisson_Precondition(femspace,quad);
   LegendreSPECollocationSeparableEllipticProblem* LS=new LegendreSPECollocationSeparableEllipticProblem(femspace,quad);
   problem->setLocalSolver(LS);
   problem->solve();

// output FEM solution results
   Vector *uh=problem->getSolution(0);
   Coefficient *f=problem->getExactSolution();
   femspace->outputTecPlotDataFile("uhplot.dat", *uh, 30);
   cout<<setprecision(15)<<femspace->L2Error(f, *uh)<<endl;


// output L^2 projection results
   Vector ui;
   femspace->interpolantFun(f, ui);
 
//   cout<<ui<<endl;

//    femspace->projection(f, ui);
   cout<<" L2 error of U for k="<<n<<endl;
   cout<<setprecision(15)<<femspace->L2Error(f, ui)<<endl;
    //grid->outputTecPlotDataFile("uplot.dat", ui, "cubicmesh1x1x1.dat");



// output error
   Vector E=(*uh)-ui;
   femspace->outputTecPlotDataFile("uplot.dat", ui,30);
   femspace->outputTecPlotDataFile("errorplot.dat", E,30);


// delete constructed objects
   delete trial;
   delete grid;
   delete femspace;
   //delete problem;
}
