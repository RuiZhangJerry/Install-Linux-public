#include "SE_Variabal_Coeff_Poisson_Precondition_test.h"

Matrix MatrixCoefficient::m(Vector x){
    Matrix a(3, 3);
    a=0.0;
//	 a[0][0]=1.0;
//	 a[1][1]=1.0;
//     a[2][2]=1.0;
	a[0][0]=sin(x[0]*x[1]*x[2])+2.0;
	a[1][1]=cos(x[0]*x[1]*x[2])+2.0;
    a[2][2]=sin(x[0]*x[1]*x[2])+2.0;
	return a;
}

DOUBLE RHSFunc::d(Vector x){
	return -((x[0]*x[0]*x[1]*x[1]+ x[0]*x[0]*x[2]*x[2] + x[2]*x[2]*x[1]*x[1])*exp(x[0]*x[1]*x[2])\
	        -sin(x[1])-cos(x[2]));//+x[1]*x[2]*exp(x[0]*x[1]*x[2]);
	//return 0.0;	
	//return (12.0-8.0*(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]))*exp(-x[0]*x[0]-x[1]*x[1]-x[2]*x[2]);
//    return 3.0*pi*pi*sin(pi*x[0])*sin(pi*x[1])*sin(pi*x[2]);

//    DOUBLE var=x[0]*x[0]+x[1]*x[1]+x[2]*x[2];
//	DOUBLE prod=x[0]*x[1]*x[2];
    //return -8.0*(var-1.5)*exp(-var);
	
//	return  4.0*(sin(prod)+2.0+prod*cos(prod)+cos(prod)+2.0-prod*sin(prod)+sin(prod)+2.0+prod*cos(prod))*exp(-var)-\
//		    8.0*(x[0]*x[0]*(sin(prod)+2.0)+x[1]*x[1]*(cos(prod)+2.0)+x[2]*x[2]*(sin(prod)+2.0))*exp(-var);
}

DOUBLE BoundaryCondition::d(Vector x){
	return exp(x[0]*x[1]*x[2])+sin(x[1])+cos(x[2]);
	//return  (x[0])+x[1]+x[2];
//    return sin(pi*x[0])*sin(pi*x[1])*sin(pi*x[2]);
    //return 2.0*exp(-x[0]*x[0]-x[1]*x[1]-x[2]*x[2]);
//    return x[0]*x[1]*x[2];
//   return sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]);
}

DOUBLE ExactSolution::d(Vector x){
	return exp(x[0]*x[1]*x[2])+sin(x[1])+cos(x[2]);
	//return (x[0])+x[1]+x[2];
	//return 2.0*exp(-x[0]*x[0]-x[1]*x[1]-x[2]*x[2]);
}


void SE_Variabal_Coeff_Poisson_Precondition::computeRHS(){
	INT i, j,  k;
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    
    Grid3D *grid=femspace[0]->getGrid3D();
    INT nc=grid->getNElement();
    
    PShapeFunction psf=femspace[0]->getTestFunction(0);
    INT eledof=psf->degreeOfFreedom();

    RHS[0]=new Vector(femspace[0]->degreeOfFreedom());
    INT np=quadrature->getNPoints();
    Matrix   qp=quadrature->getPoints();
    DOUBLE  *wts=quadrature->getWeights();

    Vector tmpv(psf->degreeOfFreedom());
    INT INDEX[eledof];
	for (i=0; i<nc; i++){
        Element3D *e=grid->getElement(i);
        femspace[0]->getGlobalIndex(i, INDEX);
        Vector temv(3), lambda(3), x;
        temv=0.0;
        for (j=0; j<np; j++){           // do the quadrature by the rule specified by the
            lambda[0]=qp[0][j];         // object "quadrature".
            lambda[1]=qp[1][j];
            lambda[2]=qp[2][j];
            x=space->mapping(i,lambda);
            DOUBLE ja=space->jacobi(i,lambda); 
            Matrix val;
            psf->phi(lambda, val);
            for (INT ii=0; ii<eledof; ii++)
                tmpv[ii]+=coefficient_ptr[2]->d(x)*val[0][ii]*wts[j];//*fabs(ja);
        }

		for (INT ii=0; ii<psf->degreeOfFreedom(); ii++)
                (*RHS[0])[INDEX[ii]]+=tmpv[ii];
	}
}

void SE_Variabal_Coeff_Poisson_Precondition::computeLocalMatrices(INT index){
	SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    LAGRANGE_3D_CUBE *pTrial=(LAGRANGE_3D_CUBE*)femspace[0]->getTrialFunction(index);
    INT j, k, ii, jj;
	SMGM[0]=new Sparse(femspace[0]->degreeOfFreedom(), femspace[0]->degreeOfFreedom());
    INT eledof=pTrial->degreeOfFreedom();

    INT ix[eledof], iy[eledof], iz[eledof];
    pTrial->getFreedomTensorIndex(iy, ix, iz);

    INT nq=femspace[0]->getTestFunction(0)->getPolynomialDegree();
    LAGRANGEShapeFunction *ptrial=new LAGRANGEShapeFunction(nq);
    DOUBLE glp[nq+1], wt[nq+1];
    Quadrature* quad1D=new Quadrature(INTERVAL, GAUSS_LOBATTAO_QUADRATURE);
    quad1D->permuteData(nq+1);
    Quadrature::LegendreGaussLobatto(nq+1, glp, wt);
    Vector coord(nq+1), xi(1);
    coord=glp;
    ptrial->setNodePointCoord(coord);//Be caution!-)
    ptrial->computeCoefficient();
    Vector GradMatrix1D;
    GradMatrix1D.setDim((nq+1)*(nq+1));
    GradMatrix1D=0.0;
    PMatrix gradval=new Matrix();
    for(INT i=0;i<nq+1;i++){
        xi[0]=glp[i];
        ptrial->grad_phi(xi,*gradval);
        for(INT j=0;j<nq+1;j++){
            GradMatrix1D[j+i*(nq+1)]=(*gradval)[0][j];
        }
    }
    delete gradval;

    if (MLM[0]==NULL){
        MLM[0]=new Matrix(eledof, eledof);
        MLM[1]=new Matrix(eledof, eledof);
    }

    Vector x(3);
    for(INT i=0;i<eledof;i++){
    	for(INT j=i;j<eledof;j++){
    		if(iy[i]==iy[j]&& iz[i]==iz[j]){ //Compute I_1 !-)
    			for(INT m=0;m<nq+1;m++){
    				x[0]=glp[m]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]];
    				Matrix A=space->TransformedLaplace(index,x);
//    				(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[i]+m*(nq+1)]*GradMatrix1D[ix[j]+m*(nq+1)]*wt[m]*wt[iy[i]]*wt[iz[i]];
    				(*MLM[0])(i+1,j+1)+= A[0][0]*GradMatrix1D[ix[i]+m*(nq+1)]*GradMatrix1D[ix[j]+m*(nq+1)]*wt[m]*wt[iy[i]]*wt[iz[i]];
    			}
//				x=glp[ix[j]]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]];
//				Matrix A=space->JMIT(index,x);
//				PMatrix* dA=space->DiffJMIT(index,x);
//				DOUBLE g=A[0][0]*(*dA[0])[0][0]+A[1][0]*(*dA[0])[1][0]+A[2][0]*(*dA[0])[2][0]+\
//						 A[0][0]*(*dA[1])[0][1]+A[1][0]*(*dA[1])[1][1]+A[2][0]*(*dA[1])[2][1]+\
//						 A[0][0]*(*dA[2])[0][2]+A[1][0]*(*dA[2])[1][2]+A[2][0]*(*dA[2])[2][2];
//			//	(*MLM[0])(i+1,j+1)+=g*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];
    		}

    		if(ix[i]==ix[j]&&iz[i]==iz[j]){ //Compute I_5 !-)
    			for(INT m=0;m<nq+1;m++){
    				x[0]=glp[ix[i]]; x[1]=glp[m]; x[2]=glp[iz[i]];
    				Matrix A=space->TransformedLaplace(index,x);
//    				(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[iy[i]+m*(nq+1)]*GradMatrix1D[iy[j]+m*(nq+1)]*wt[m]*wt[ix[i]]*wt[iz[i]];
    				(*MLM[0])(i+1,j+1)+= A[1][1]*GradMatrix1D[iy[i]+m*(nq+1)]*GradMatrix1D[iy[j]+m*(nq+1)]*wt[m]*wt[ix[i]]*wt[iz[i]];
    			}
    			
//    			x=glp[ix[i]]; x[1]=glp[iy[j]]; x[2]=glp[iz[i]];
//				Matrix A=space->JMIT(index,x);
//				PMatrix* dA=space->DiffJMIT(index,x);
//				DOUBLE g=A[0][1]*(*dA[0])[0][0]+A[1][1]*(*dA[0])[1][0]+A[2][1]*(*dA[0])[2][0]+\
//						 A[0][1]*(*dA[1])[0][1]+A[1][1]*(*dA[1])[1][1]+A[2][1]*(*dA[1])[2][1]+\
//						 A[0][1]*(*dA[2])[0][2]+A[1][1]*(*dA[2])[1][2]+A[2][1]*(*dA[2])[2][2];
//			//	(*MLM[0])(i+1,j+1)+=g*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];
    		}

    		if(ix[i]==ix[j]&&iy[i]==iy[j]){ //Compute I_9 !-)
    			for(INT m=0;m<nq+1;m++){
    				x[0]=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[m];
    				Matrix A=space->TransformedLaplace(index,x);
//    				(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[iz[i]+m*(nq+1)]*GradMatrix1D[iz[j]+m*(nq+1)]*wt[m]*wt[ix[i]]*wt[iy[i]];
    				(*MLM[0])(i+1,j+1)+= A[2][2]*GradMatrix1D[iz[i]+m*(nq+1)]*GradMatrix1D[iz[j]+m*(nq+1)]*wt[m]*wt[ix[i]]*wt[iy[i]];
    			}
    			
//    			x=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[iz[j]];
//				Matrix A=space->JMIT(index,x);
//				PMatrix* dA=space->DiffJMIT(index,x);
//				DOUBLE g=A[0][2]*(*dA[0])[0][0]+A[1][2]*(*dA[0])[1][0]+A[2][2]*(*dA[0])[2][0]+\
//						 A[0][2]*(*dA[1])[0][1]+A[1][2]*(*dA[1])[1][1]+A[2][2]*(*dA[1])[2][1]+\
//						 A[0][2]*(*dA[2])[0][2]+A[1][2]*(*dA[2])[1][2]+A[2][2]*(*dA[2])[2][2];
//				(*MLM[0])(i+1,j+1)+=g*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    		}

    		if(iz[i]==iz[j]){ //Compute I_2 !-)
    			x[0]=glp[ix[j]]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]]; 
    			Matrix A=space->TransformedLaplace(index,x);
//    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*GradMatrix1D[iy[j]+iy[i]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];
    			(*MLM[0])(i+1,j+1)+= A[1][0]*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*GradMatrix1D[iy[j]+iy[i]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];

    			x[0]=glp[ix[i]]; x[1]=glp[iy[j]]; x[2]=glp[iz[i]];
    			A=space->TransformedLaplace(index,x);
//    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[j]+ix[i]*(nq+1)]*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];
    			(*MLM[0])(i+1,j+1)+= A[0][1]*GradMatrix1D[ix[j]+ix[i]*(nq+1)]*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];
    		}

    		if(iy[i]==iy[j]){ //Compute I_3 !-)
    			x[0]=glp[ix[j]]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]];
    			Matrix A=space->TransformedLaplace(index,x);
//    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*GradMatrix1D[iz[j]+iz[i]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];
    			(*MLM[0])(i+1,j+1)+= A[2][0]*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*GradMatrix1D[iz[j]+iz[i]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];

    			x[0]=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[iz[j]];
    			A=space->TransformedLaplace(index,x);
//    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[j]+ix[i]*(nq+1)]*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    			(*MLM[0])(i+1,j+1)+= A[0][2]*GradMatrix1D[ix[j]+ix[i]*(nq+1)]*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    		}
    		
    		if(ix[i]==ix[j]){
    			x[0]=glp[ix[i]]; x[1]=glp[iy[j]]; x[2]=glp[iz[i]];
    			Matrix A=space->TransformedLaplace(index,x);
 //   			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*GradMatrix1D[iz[j]+iz[i]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];
    			(*MLM[0])(i+1,j+1)+= A[2][1]*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*GradMatrix1D[iz[j]+iz[i]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];

    			x[0]=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[iz[j]];
    			A=space->TransformedLaplace(index,x);
//    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[iy[j]+iy[i]*(nq+1)]*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    			(*MLM[0])(i+1,j+1)+= A[1][2]*GradMatrix1D[iy[j]+iy[i]*(nq+1)]*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    		}
    		(*MLM[0])(j+1,i+1)=(*MLM[0])(i+1,j+1); //To make the solver faster we suppose the coefficient matrix A is symetrical !-)
    	}
    }
    
    for(INT i=0;i<eledof;i++){
    	for(INT j=0;j<eledof;j++){
    		if(iy[i]==iy[j]&& iz[i]==iz[j]){ //Compute I_1 !-)
				x=glp[ix[j]]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]];
				Matrix A=space->JMIT(index,x);
				PMatrix* dA=space->DiffJMIT(index,x);
				DOUBLE g=A[0][0]*(*dA[0])[0][0]+A[1][0]*(*dA[0])[1][0]+A[2][0]*(*dA[0])[2][0]+\
						 A[0][0]*(*dA[1])[0][1]+A[1][0]*(*dA[1])[1][1]+A[2][0]*(*dA[1])[2][1]+\
						 A[0][0]*(*dA[2])[0][2]+A[1][0]*(*dA[2])[1][2]+A[2][0]*(*dA[2])[2][2];
				(*MLM[1])(i+1,j+1)+=g*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];
    		}
    		
    		if(ix[i]==ix[j]&&iz[i]==iz[j]){ //Compute I_5 !-)
    			x=glp[ix[i]]; x[1]=glp[iy[j]]; x[2]=glp[iz[i]];
				Matrix A=space->JMIT(index,x);
				PMatrix* dA=space->DiffJMIT(index,x);
				DOUBLE g=A[0][1]*(*dA[0])[0][0]+A[1][1]*(*dA[0])[1][0]+A[2][1]*(*dA[0])[2][0]+\
						 A[0][1]*(*dA[1])[0][1]+A[1][1]*(*dA[1])[1][1]+A[2][1]*(*dA[1])[2][1]+\
						 A[0][1]*(*dA[2])[0][2]+A[1][1]*(*dA[2])[1][2]+A[2][1]*(*dA[2])[2][2];
				(*MLM[1])(i+1,j+1)+=g*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];
    		}
    		
    		if(ix[i]==ix[j]&&iy[i]==iy[j]){ //Compute I_9 !-)
    			x=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[iz[j]];
				Matrix A=space->JMIT(index,x);
				PMatrix* dA=space->DiffJMIT(index,x);
				DOUBLE g=A[0][2]*(*dA[0])[0][0]+A[1][2]*(*dA[0])[1][0]+A[2][2]*(*dA[0])[2][0]+\
						 A[0][2]*(*dA[1])[0][1]+A[1][2]*(*dA[1])[1][1]+A[2][2]*(*dA[1])[2][1]+\
						 A[0][2]*(*dA[2])[0][2]+A[1][2]*(*dA[2])[1][2]+A[2][2]*(*dA[2])[2][2];
				(*MLM[1])(i+1,j+1)+=g*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    		}
		}
	}
//	cout<<(*MLM[1])<<endl;
}
/*
void SE_Variabal_Coeff_Poisson_Precondition::computeLocalMatrices(INT index){
	SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    LAGRANGE_3D_CUBE *pTrial=(LAGRANGE_3D_CUBE*)femspace[0]->getTrialFunction(index);
    INT j, k, ii, jj;
	SMGM[0]=new Sparse(femspace[0]->degreeOfFreedom(), femspace[0]->degreeOfFreedom());
    INT eledof=pTrial->degreeOfFreedom();

    INT ix[eledof], iy[eledof], iz[eledof];
    pTrial->getFreedomTensorIndex(iy, ix, iz);

    INT nq=femspace[0]->getTestFunction(0)->getPolynomialDegree();
    LAGRANGEShapeFunction *ptrial=new LAGRANGEShapeFunction(nq);
    DOUBLE glp[nq+1], wt[nq+1];
    Quadrature* quad1D=new Quadrature(INTERVAL, GAUSS_LOBATTAO_QUADRATURE);
    quad1D->permuteData(nq+1);
    Quadrature::LegendreGaussLobatto(nq+1, glp, wt);
    Vector coord(nq+1), xi(1);
    coord=glp;
    ptrial->setNodePointCoord(coord);//Be caution!-)
    ptrial->computeCoefficient();
    Vector GradMatrix1D;
    GradMatrix1D.setDim((nq+1)*(nq+1));
    GradMatrix1D=0.0;
    PMatrix gradval=new Matrix();
    for(INT i=0;i<nq+1;i++){
        xi[0]=glp[i];
        ptrial->grad_phi(xi,*gradval);
        for(INT j=0;j<nq+1;j++){
            GradMatrix1D[j+i*(nq+1)]=(*gradval)[0][j];
        }
    }
    delete gradval;

    if (MLM[0]==NULL){
        MLM[0]=new Matrix(eledof, eledof);
        MLM[1]=new Matrix(eledof, eledof);
    }

    Vector x(3);
    for(INT i=0;i<eledof;i++){
    	for(INT j=i;j<eledof;j++){
    		if(iy[i]==iy[j]&& iz[i]==iz[j]){ //Compute I_1 !-)
    			for(INT m=0;m<nq+1;m++){
    				x[0]=glp[m]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]];
    				Matrix A=space->JMIT(index,x);
    				DOUBLE ja=space->jacobi(index,x);
    				DOUBLE G1=(A[0][0]*A[0][0]+A[1][0]*A[1][0]+A[2][0]*A[2][0])*fabs(ja);
    				(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[i]+m*(nq+1)]*GradMatrix1D[ix[j]+m*(nq+1)]*wt[m]*wt[iy[i]]*wt[iz[i]];
    			}
    		}

    		if(ix[i]==ix[j]&&iz[i]==iz[j]){ //Compute I_5 !-)
    			for(INT m=0;m<nq+1;m++){
    				x[0]=glp[ix[i]]; x[1]=glp[m]; x[2]=glp[iz[i]];
    				Matrix A=space->JMIT(index,x);
    				DOUBLE ja=space->jacobi(index,x);
    				DOUBLE G1=(A[0][1]*A[0][1]+A[1][1]*A[1][1]+A[2][1]*A[2][1])*fabs(ja);
    				(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[iy[i]+m*(nq+1)]*GradMatrix1D[iy[j]+m*(nq+1)]*wt[m]*wt[ix[i]]*wt[iz[i]];
    			}
    		}

    		if(ix[i]==ix[j]&&iy[i]==iy[j]){ //Compute I_9 !-)
    			for(INT m=0;m<nq+1;m++){
    				x[0]=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[m];
    				Matrix A=space->JMIT(index,x);
    				DOUBLE ja=space->jacobi(index,x);
    				DOUBLE G1=(A[0][2]*A[0][2]+A[1][2]*A[1][2]+A[2][2]*A[2][2])*fabs(ja);
    				(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[iz[i]+m*(nq+1)]*GradMatrix1D[iz[j]+m*(nq+1)]*wt[m]*wt[ix[i]]*wt[iy[i]];
    			}
    		}

    		if(iz[i]==iz[j]){ //Compute I_2 !-)
    			x[0]=glp[ix[j]]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]]; 
    			Matrix A=space->JMIT(index,x);
    			DOUBLE ja=space->jacobi(index,x);
    			DOUBLE G1=(A[0][0]*A[0][1]+A[1][0]*A[1][1]+A[2][0]*A[2][1])*fabs(ja);
    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*GradMatrix1D[iy[j]+iy[i]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];

    			x[0]=glp[ix[i]]; x[1]=glp[iy[j]]; x[2]=glp[iz[i]];
    			A=space->JMIT(index,x);
    			ja=space->jacobi(index,x);
    			G1=(A[0][1]*A[0][0]+A[1][0]*A[1][1]+A[2][0]*A[2][1])*fabs(ja);
    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[j]+ix[i]*(nq+1)]*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];
    		}

    		if(iy[i]==iy[j]){ //Compute I_3 !-)
    			x[0]=glp[ix[j]]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]];
    			Matrix A=space->JMIT(index,x);
    			DOUBLE ja=space->jacobi(index,x);
    			DOUBLE G1=(A[0][0]*A[0][2]+A[1][0]*A[1][2]+A[2][0]*A[2][2])*fabs(ja);
    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*GradMatrix1D[iz[j]+iz[i]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];

    			x[0]=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[iz[j]];
    			A=space->JMIT(index,x);
    			ja=space->jacobi(index,x);
    			G1=(A[0][0]*A[0][2]+A[1][0]*A[1][2]+A[2][0]*A[2][2])*fabs(ja);
    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[ix[j]+ix[i]*(nq+1)]*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    		}
    		
    		if(ix[i]==ix[j]){
    			x[0]=glp[ix[i]]; x[1]=glp[iy[j]]; x[2]=glp[iz[i]];
    			Matrix A=space->JMIT(index,x);
    			DOUBLE ja=space->jacobi(index,x);
    			DOUBLE G1=(A[0][1]*A[0][2]+A[1][1]*A[1][2]+A[2][1]*A[2][2])*fabs(ja);
    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*GradMatrix1D[iz[j]+iz[i]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];

    			x[0]=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[iz[j]];
    			A=space->JMIT(index,x);
    			ja=space->jacobi(index,x);
    			G1=(A[0][1]*A[0][2]+A[1][1]*A[1][2]+A[2][1]*A[2][2])*fabs(ja);
    			(*MLM[0])(i+1,j+1)+= G1*GradMatrix1D[iy[j]+iy[i]*(nq+1)]*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    		}
    		(*MLM[0])(j+1,i+1)=(*MLM[0])(i+1,j+1); //To make the solver faster we suppose the coefficient matrix A is symetrical !-)
    	}
    }
    
    for(INT i=0;i<eledof;i++){
    	for(INT j=0;j<eledof;j++){
    		if(iy[i]==iy[j]&& iz[i]==iz[j]){ //Compute I_1 !-)
				x=glp[ix[j]]; x[1]=glp[iy[i]]; x[2]=glp[iz[i]];
				Matrix A=space->JMIT(index,x);
				DOUBLE ja=space->jacobi(index,x);
				DOUBLE g=fabs(ja)*A[0][0];
//				PMatrix* dA=space->DiffJMIT(index,x);
//				DOUBLE g=A[0][0]*(*dA[0])[0][0]+A[1][0]*(*dA[0])[1][0]+A[2][0]*(*dA[0])[2][0]+\
//						 A[0][0]*(*dA[1])[0][1]+A[1][0]*(*dA[1])[1][1]+A[2][0]*(*dA[1])[2][1]+\
//						 A[0][0]*(*dA[2])[0][2]+A[1][0]*(*dA[2])[1][2]+A[2][0]*(*dA[2])[2][2];
				(*MLM[1])(i+1,j+1)+=g*GradMatrix1D[ix[i]+ix[j]*(nq+1)]*wt[ix[j]]*wt[iy[i]]*wt[iz[i]];
    		}
    		
    		if(ix[i]==ix[j]&&iz[i]==iz[j]){ //Compute I_5 !-)
    			x=glp[ix[i]]; x[1]=glp[iy[j]]; x[2]=glp[iz[i]];
				Matrix A=space->JMIT(index,x);
				DOUBLE ja=space->jacobi(index,x);
				DOUBLE g=fabs(ja)*A[0][1];
//				PMatrix* dA=space->DiffJMIT(index,x);
//				DOUBLE g=A[0][1]*(*dA[0])[0][0]+A[1][1]*(*dA[0])[1][0]+A[2][1]*(*dA[0])[2][0]+\
//						 A[0][1]*(*dA[1])[0][1]+A[1][1]*(*dA[1])[1][1]+A[2][1]*(*dA[1])[2][1]+\
//						 A[0][1]*(*dA[2])[0][2]+A[1][1]*(*dA[2])[1][2]+A[2][1]*(*dA[2])[2][2];
				(*MLM[1])(i+1,j+1)+=g*GradMatrix1D[iy[i]+iy[j]*(nq+1)]*wt[ix[i]]*wt[iy[j]]*wt[iz[i]];
    		}
    		
    		if(ix[i]==ix[j]&&iy[i]==iy[j]){ //Compute I_9 !-)
    			x=glp[ix[i]]; x[1]=glp[iy[i]]; x[2]=glp[iz[j]];
				Matrix A=space->JMIT(index,x);
				DOUBLE ja=space->jacobi(index,x);
				DOUBLE g=fabs(ja)*A[0][2];
//				PMatrix* dA=space->DiffJMIT(index,x);
//				DOUBLE g=A[0][2]*(*dA[0])[0][0]+A[1][2]*(*dA[0])[1][0]+A[2][2]*(*dA[0])[2][0]+\
//						 A[0][2]*(*dA[1])[0][1]+A[1][2]*(*dA[1])[1][1]+A[2][2]*(*dA[1])[2][1]+\
//						 A[0][2]*(*dA[2])[0][2]+A[1][2]*(*dA[2])[1][2]+A[2][2]*(*dA[2])[2][2];
				(*MLM[1])(i+1,j+1)+=g*GradMatrix1D[iz[i]+iz[j]*(nq+1)]*wt[ix[i]]*wt[iy[i]]*wt[iz[j]];
    		}
		}
	}
//	cout<<(*MLM[1])<<endl;
}*/

void SE_Variabal_Coeff_Poisson_Precondition::assemble(){
    Grid3D *grid=femspace[0]->getGrid3D();
	INT nc=grid->getNElement();
	INT i, j, k;
	
 	old_SMGM=new Sparse(femspace[0]->degreeOfFreedom(), femspace[0]->degreeOfFreedom());
	for (i=0; i<nc; i++){
		tic();
		computeLocalMatrices(i);
		toc();  
        INT eledof=femspace[0]->degreeOfFreedom(i);
        INT INDEX[eledof];
        femspace[0]->getGlobalIndex(i, INDEX);
        for (j=0; j<eledof; j++){               // assemble the global stiff matrix
			for (k=0; k<eledof; k++){
				(*SMGM[0])(INDEX[j]+1,INDEX[k]+1) =(*MLM[0])(j+1,k+1)+(*MLM[1])(k+1,j+1);
				(*old_SMGM)(INDEX[j]+1,INDEX[k]+1)=(*MLM[0])(j+1,k+1)+(*MLM[1])(k+1,j+1);
			}
        }
        //cout<<(*MLM[0])+(*MLM[1]).transpose()<<endl;
	}
}

void SE_Variabal_Coeff_Poisson_Precondition::imposeBoundaryCondition(){
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid3D *grid=femspace[0]->getGrid3D();
    INT i, j, k;
    Vector pp(femspace[0]->degreeOfFreedom());
    Vector lambda(3), x(3);
    INT dof=space->degreeOfFreedom();
    for (i=0; i<grid->getNBPatch(); i++){
        BoundaryPatch3D *bp=grid->getBoundaryPatch(i);
        for (j=0; j<bp->getNVertex(); j++){
            Vertex3D *vertex=bp->getVertex(j);          // Nodes on vertexes
            x=vertex->getCoord();
            pp[vertex->getIndex()] =coefficient_ptr[1]->d(x);//cout<<pp<<endl;
        }

        for (j=0; j<bp->getNEdge(); j++){               // Nodes on edges
            Edge3D *edge=bp->getEdge(j);
            Face3D *pf=edge->getRelatedFace(0);
            Element3D *e=pf->getNeighborElement(0);
            INT index[femspace[0]->degreeOfFreedom(e->getIndex())];
            femspace[0]->getGlobalIndex(e->getIndex(), index);
            INT ie=e->getEdgeLocalIndex(edge);
            INT ne=femspace[0]->getTrialFunction(e->getIndex())->getNEdgeNode();
            k=e->getNVertex()+ne*ie;
            Matrix coord=femspace[0]->getTrialFunction(e->getIndex())->getNodeCoord();
            for (INT s=0; s<ne; s++){
                lambda[0]=coord[0][k+s];	lambda[1]=coord[1][k+s];
                lambda[2]=coord[2][k+s];
                x=space->mapping(e->getIndex(), lambda);
                pp[index[k+s]] =coefficient_ptr[1]->d(x);
            }
        }

        for (j=0; j<bp->getNFace(); j++){               // Nodes on faces
            Face3D *pf=bp->getFace(j);
            Element3D *e=pf->getNeighborElement(0);
            INT index[femspace[0]->degreeOfFreedom(e->getIndex())];
            femspace[0]->getGlobalIndex(e->getIndex(), index);
            INT ie=e->getFaceLocalIndex(pf);
            INT ne=femspace[0]->getTrialFunction(e->getIndex())->getNEdgeNode();
            INT nf=femspace[0]->getTrialFunction(e->getIndex())->getNFaceNode();
            k=e->getNVertex()+e->getNEdge()*ne+ie*nf;
            Matrix coord=femspace[0]->getTrialFunction(e->getIndex())->getNodeCoord();
            for (INT s=0; s<nf; s++){
                lambda[0]=coord[0][k+s];	lambda[1]=coord[1][k+s];
                lambda[2]=coord[2][k+s];
                x=space->mapping(e->getIndex(), lambda);
                pp[index[k+s]] =coefficient_ptr[1]->d(x);
            }
        }
    }

    (*RHS[0])=(*RHS[0])-(*SMGM[0])*pp;
	//cout<<pp<<endl;
    for (i=0; i<grid->getNBPatch(); i++){
        BoundaryPatch3D *bp=grid->getBoundaryPatch(i);
        for (j=0; j<bp->getNVertex(); j++){
            Vertex3D *vertex=bp->getVertex(j);
            INT ii=vertex->getIndex();
            SMGM[0]->zeroRow(ii);
            SMGM[0]->zeroColumn(ii);
            (*SMGM[0])(ii+1, ii+1)=1.0;
            (*RHS[0])[ii]=pp[ii];
        }

        for (j=0; j<bp->getNEdge(); j++){
            Edge3D *edge=bp->getEdge(j);
            Face3D *pf=edge->getRelatedFace(0);
            Element3D *e=pf->getNeighborElement(0);
            INT index[femspace[0]->degreeOfFreedom(e->getIndex())];
            femspace[0]->getGlobalIndex(e->getIndex(), index);
            INT ie=e->getEdgeLocalIndex(edge);
            INT ne=femspace[0]->getTrialFunction(e->getIndex())->getNEdgeNode();
            k=e->getNVertex()+ne*ie;
            for (INT s=0; s<ne; s++){
                SMGM[0]->zeroRow(index[k+s]);
                SMGM[0]->zeroColumn(index[k+s]);
                (*SMGM[0])(index[k+s]+1, index[k+s]+1)=1.0;
                (*RHS[0])[index[k+s]]=pp[index[k+s]];
            }
        }

        for (j=0; j<bp->getNFace(); j++){               // Nodes on faces
            Face3D *pf=bp->getFace(j);
            Element3D *e=pf->getNeighborElement(0);
            INT index[femspace[0]->degreeOfFreedom(e->getIndex())];
            femspace[0]->getGlobalIndex(e->getIndex(), index);
            INT ie=e->getFaceLocalIndex(pf);
            INT ne=femspace[0]->getTrialFunction(e->getIndex())->getNEdgeNode();
            INT nf=femspace[0]->getTrialFunction(e->getIndex())->getNFaceNode();
            k=e->getNVertex()+e->getNEdge()*ne+ie*nf;
            for (INT s=0; s<nf; s++){
                SMGM[0]->zeroRow(index[k+s]);
                SMGM[0]->zeroColumn(index[k+s]);
                (*SMGM[0])(index[k+s]+1, index[k+s]+1)=1.0;
                (*RHS[0])[index[k+s]]=pp[index[k+s]];
            }
        }
    }
}

Matrix SE_Variabal_Coeff_Poisson_Precondition::ComputeLambda(){
	SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    INT Dof=femspace[0]->degreeOfFreedom();
	
	Matrix Lambda(Dof,Dof);
	for(INT i=0;i<Dof;i++){
		(Lambda)[i][i]=1.0/sqrt((*SMGM[0])(i+1,i+1));
	}
	
	return Lambda;
}

Vector SE_Variabal_Coeff_Poisson_Precondition::globalMatrixProdVector(const Vector &p){
	Vector v=p;
	return (*SMGM[0])*v;
}

Vector SE_Variabal_Coeff_Poisson_Precondition::globalPreconditionerSolve(const Vector &p){
	SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid3D *grid=femspace[0]->getGrid3D();
    INT i, j, k;
    Vector pp(femspace[0]->degreeOfFreedom());
    Vector lambda(3), x(3);
    INT dof=space->degreeOfFreedom();
	LAGRANGE_3D_CUBE *psf=(LAGRANGE_3D_CUBE *)femspace[0]->getTrialFunction(0);
	int n=femspace[0]->getTrialFunction(0)->getPolynomialDegree();
	INT eledof=psf->degreeOfFreedom();
	Matrix   qp=quadrature->getPoints();
	DOUBLE  *wts=quadrature->getWeights();
	//DOUBLE ja=space->jacobi(0,x);
    INT nodeindex[eledof];
    psf->freedomToQuadrature(nodeindex);

	int start=8+(n-1)*12+(n-1)*(n-1)*6;
	Vector bv(start);
	Vector v=p;
	Vector bbv(eledof);
//	Matrix Lambda=ComputeLambda();
//	v=Lambda*v;
	for(INT i=0;i<start;i++){
		bv[i]=v[i];
		bbv[i]=v[i];
	}
	//cout<<v<<endl;
	LocalSolver->setBoundaryValue(&bv);
	v=v+(*old_SMGM)*bbv;
	for(INT ii=start;ii<eledof;ii++){
		x[0]=qp[0][nodeindex[ii]];
		x[1]=qp[1][nodeindex[ii]];
		x[2]=qp[2][nodeindex[ii]];
		DOUBLE ja=space->jacobi(0,x);
		v[ii]=v[ii]/(wts[nodeindex[ii]]);
		//v[ii]=v[ii]/(wts[ii]);
	}
	//cout<<v<<endl;
	LocalSolver->setRHSValue(&v);
	LocalSolver->solve();
	Vector* temv=LocalSolver->getSolution(0);
	v=(*temv);
    //return Lambda*v;
	return v;
}

void SE_Variabal_Coeff_Poisson_Precondition::solve(){
    setNMLM(2);
    setNRHS(1);
    setNSMGM(1);
    setNSolution(1);

    INT Dof=femspace[0]->degreeOfFreedom();
    //tic();
    assemble();               // assemble the resulted linear system
    //toc();
    SMGM[0]->restoreBuffer();
    //tic();
    computeRHS();             // compute right hand side
    //toc();
    //cout<<*RHS[0]<<endl;
    //Vector rhs=globalPreconditionerSolve(*RHS[0]);
    //tic();
    imposeBoundaryCondition();// impose boundary condition
    //cout<<*RHS[0]<<endl;
   // Vector rhs=globalPreconditionerSolve(*RHS[0]);
    //toc();
    Vector v0(Dof);
    v0=0.0;
    int MAX_ITER=500,restart=180;
    DOUBLE tol=1.0e-14;
    //matrixFreePGMRES(1, v0, *RHS[0],restart, MAX_ITER, tol,1);
    solveLinearSystem(0, 0, _PCG_, v0, MAX_ITER, tol);  // solve linear system
    cout<<"iterations for solving linear system: "<<MAX_ITER<<endl;
    cout<<"residual of iterations: "<<tol<<endl;
    
    solution[0]=new Vector(v0);
}













