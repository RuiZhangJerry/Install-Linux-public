#ifndef SE_Variabal_Coeff_Poisson_Precondition_test
#define SE_Variabal_Coeff_Poisson_Precondition_test

#include <iostream>
#include <math.h>

#include "SpectralElementspace.h"
#include "FEMProblem.h"
#include "lagrange3Dsf.h"
#include "Legendre_spectral_collocation_method_for_separable_elliptic_equation.h"

using namespace std;

class MatrixCoefficient : public Coefficient{

public:
	virtual Matrix m(Vector x);
};

class RHSFunc : public Coefficient{

public:
	virtual DOUBLE d(Vector x);
};

class BoundaryCondition : public Coefficient{

public:
	virtual DOUBLE d(Vector x);
};

class ExactSolution : public Coefficient{

public:
	virtual DOUBLE d(Vector x);
};

class SE_Variabal_Coeff_Poisson_Precondition:public FEMProblem{
	Matrix* GlobalMatrix;
	Sparse* old_SMGM;
	
	LegendreSPECollocationSeparableEllipticProblem* LocalSolver; 
	FEMSpace* refspace;
	public:
		SE_Variabal_Coeff_Poisson_Precondition(FEMSpace *fs, Quadrature *quad):FEMProblem(fs,quad){
			coefficient_ptr=new Coefficient *[4];
			coefficient_ptr[0]=new MatrixCoefficient;
			coefficient_ptr[1]=new BoundaryCondition;
			coefficient_ptr[2]=new RHSFunc;
			coefficient_ptr[3]=new ExactSolution;
			
			old_SMGM=NULL;
		}
		~SE_Variabal_Coeff_Poisson_Precondition(){
			delete[] coefficient_ptr;
		}
		
		void setLocalSolver(LegendreSPECollocationSeparableEllipticProblem* LS){
			LocalSolver=LS;
		}
		LegendreSPECollocationSeparableEllipticProblem* getLocalSolver(){
			return LocalSolver;
		}
		
		Coefficient *getExactSolution(){ return coefficient_ptr[3];}
    
		void setrefspace(FEMSpace* sp);
		virtual void computeRHS();
		virtual void computeLocalMatrices(INT index);
		virtual void assemble();

		virtual void imposeBoundaryCondition();
		Matrix ComputeLambda();
		
		virtual Vector globalMatrixProdVector(const Vector &p);
		virtual Vector globalPreconditionerSolve(const Vector &p);

		virtual void solve();
	
		PMatrix getSMGM();
	
};

typedef SE_Variabal_Coeff_Poisson_Precondition SEVCP;
typedef SE_Variabal_Coeff_Poisson_Precondition* pSEVCP;



#endif 

















