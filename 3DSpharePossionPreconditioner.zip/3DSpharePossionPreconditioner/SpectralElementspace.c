#include "SpectralElementspace.h"

Vector SpectralElementSpace::mapping(INT i, Vector &lambda){
	Vector v1(3), v2(3), v3(3), v4(3), v5(3), v6(3), v7(3), v8(3), v(3);
    Element3D *e=femg3d->getElement(i);
    v1=e->getVertex(0)->getCoord();
    v2=e->getVertex(1)->getCoord();
    v3=e->getVertex(2)->getCoord();
    v4=e->getVertex(3)->getCoord();

    v5=e->getVertex(4)->getCoord();
    v6=e->getVertex(5)->getCoord();
    v7=e->getVertex(6)->getCoord();
    v8=e->getVertex(7)->getCoord();
    
//    v[0]=(v2[0]-v1[0])/2.0*lambda[0]+(v2[0]+v1[0])/2.0;
//    v[1]=(v3[1]-v2[1])/2.0*lambda[1]+(v3[1]+v2[1])/2.0;
//    v[2]=(v5[2]-v1[2])/2.0*lambda[2]+(v5[2]+v1[2])/2.0;
//    
    v[0]=v1[0]*(1.0-lambda[0])*(1.0-lambda[1])/4.0+v2[0]*(1.0+lambda[0])*(1.0-lambda[1])/4.0+v3[0]*(1.0+lambda[0])*(1.0+lambda[1])/4.0+v4[0]*(1.0-lambda[0])*(1.0+lambda[1])/4.0;
    v[1]=v1[1]*(1.0-lambda[0])*(1.0-lambda[1])/4.0+v2[1]*(1.0+lambda[0])*(1.0-lambda[1])/4.0+v3[1]*(1.0+lambda[0])*(1.0+lambda[1])/4.0+v4[1]*(1.0-lambda[0])*(1.0+lambda[1])/4.0;
    v[2]=v1[2]*(1.0-lambda[0])*(1.0-lambda[1])/4.0+v2[2]*(1.0+lambda[0])*(1.0-lambda[1])/4.0+v3[2]*(1.0+lambda[0])*(1.0+lambda[1])/4.0+v4[2]*(1.0-lambda[0])*(1.0+lambda[1])/4.0;

    DOUBLE r=v.norm();
    DOUBLE b=v5.norm();

    v[0]=v[0]*((1-lambda[2])+b/r*(1.0+lambda[2]))/2.0;
    v[1]=v[1]*((1-lambda[2])+b/r*(1.0+lambda[2]))/2.0;
    v[2]=v[2]*((1-lambda[2])+b/r*(1.0+lambda[2]))/2.0;
    
    return v;
}

DOUBLE SpectralElementSpace::jacobi(INT i, Vector &lambda){
    Matrix mat=JM(i, lambda);
    return mat.det();
}

Matrix SpectralElementSpace::JM(INT i, Vector &lambda){
    Matrix mat(3, 3);
    Vector v1(3), v2(3), v3(3), v4(3), v5(3), v6(3), v7(3), v8(3), v(3);
    Element3D *e=femg3d->getElement(i);
    v1=e->getVertex(0)->getCoord();
    v2=e->getVertex(1)->getCoord();
    v3=e->getVertex(2)->getCoord();
    v4=e->getVertex(3)->getCoord();

    v5=e->getVertex(4)->getCoord();
    v6=e->getVertex(5)->getCoord();
    v7=e->getVertex(6)->getCoord();
    v8=e->getVertex(7)->getCoord();
    
//    mat[0][0]=(v2[0]-v1[0])/2.0;
//    mat[0][1]=0.0;
//    mat[0][2]=0.0;
//    mat[1][0]=0.0;
//    mat[1][1]=(v3[1]-v2[1])/2.0;
//    mat[1][2]=0.0;
//    mat[2][0]=0.0;
//    mat[2][1]=0.0;
//    mat[2][2]=(v5[2]-v1[2])/2.0;
    
    v[0]=v1[0]*(1.0-lambda[0])*(1.0-lambda[1])/4.0+v2[0]*(1.0+lambda[0])*(1.0-lambda[1])/4.0+v3[0]*(1.0+lambda[0])*(1.0+lambda[1])/4.0+v4[0]*(1.0-lambda[0])*(1.0+lambda[1])/4.0;
    v[1]=v1[1]*(1.0-lambda[0])*(1.0-lambda[1])/4.0+v2[1]*(1.0+lambda[0])*(1.0-lambda[1])/4.0+v3[1]*(1.0+lambda[0])*(1.0+lambda[1])/4.0+v4[1]*(1.0-lambda[0])*(1.0+lambda[1])/4.0;
    v[2]=v1[2]*(1.0-lambda[0])*(1.0-lambda[1])/4.0+v2[2]*(1.0+lambda[0])*(1.0-lambda[1])/4.0+v3[2]*(1.0+lambda[0])*(1.0+lambda[1])/4.0+v4[2]*(1.0-lambda[0])*(1.0+lambda[1])/4.0;
    
    DOUBLE R=v5.norm();
    DOUBLE r=v.norm();
    
    Matrix gradhatx(3, 3);
    for (int j=0; j<3; j++){
        gradhatx[0][j]=(v2[j]-v1[j])*(1.0-lambda[1])+(v3[j]-v4[j])*(1.0+lambda[1]);
        gradhatx[1][j]=(v4[j]-v1[j])*(1.0-lambda[0])+(v3[j]-v2[j])*(1.0+lambda[0]);
        gradhatx[2][j]=0.0;
    }
    DOUBLE tmp=((1.0-lambda[2])+R/r*(1.0+lambda[2]))/2.0;
    gradhatx=gradhatx/4.0;

    Vector gradr=gradhatx*v/(-r*r*r);

    DOUBLE CV1[3]={0.0, 0.0, -0.5};
    DOUBLE CV2[3]={0.0, 0.0, R/2.0};

    for (int j=0; j<3; j++){
        for (int k=0; k<3; k++){
            mat[k][j]=gradhatx[k][j]*tmp+v[j]*(CV1[k]+CV2[k]/r+(1.0+lambda[2])/2.0*R*gradr[k]);
        }
    }
//    
    return mat;
}

Matrix SpectralElementSpace::JMIT(INT i, Vector &lambda){
    Matrix mat=JM(i, lambda);
    return mat.inverse();
}

PMatrix* SpectralElementSpace::DiffJMIT(INT i, Vector &lambda){
	DOUBLE Delta=1e-5;
	Vector TEM(3);
	PMatrix* DJIM=new Matrix* [3];
	for(INT ii=0;ii<3;ii++){
		DJIM[ii]= new Matrix(3,3);
		//*DJIM[ii]=JMIT(i,lambda);
		TEM=lambda;
		TEM[ii]+=Delta;
		*DJIM[ii]=(JMIT(i,TEM)-JMIT(i,lambda))/Delta;
	}
	return DJIM;	
}

Matrix SpectralElementSpace::TransformedLaplace(INT i, Vector &lambda){
	Matrix TLaplace(3,3);
	
	TLaplace=JMIT(i,lambda).transpose()*JMIT(i,lambda);
	
	return TLaplace;
}








