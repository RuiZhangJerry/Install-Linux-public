#include "Legendre_spectral_collocation_method_for_separable_elliptic_equation.h"
//
//DOUBLE RHSFunc::d(Vector x){
//    return 3.0*sin(x[0])*sin(x[1])*sin(x[2]);
//}
//
//DOUBLE BoundaryCondition::d(Vector x){
//    DOUBLE pi=4.0*atan(1.0);
//    return sin(x[0])*sin(x[1])*sin(x[2]);
//}

////����111
//DOUBLE RHSFunc::d(Vector x){
//    DOUBLE pi=4.0*atan(1.0);
//    return 6.0*pi*pi*sin(2*pi*x[0])*sin(pi*x[1])*sin(pi*x[2]);
//}
//DOUBLE BoundaryCondition::d(Vector x){
//    DOUBLE pi=4.0*atan(1.0);
//    return sin(2*pi*x[0])*sin(pi*x[1])*sin(pi*x[2]);
//}
//
//////����2222
//DOUBLE RHSFunc::d(Vector x){
//    DOUBLE pi=4.0*atan(1.0);
//    return 6.0*pi*pi*sin(2*pi*x[0])*sin(pi*x[1])*sin(pi*x[2]);
//}
//DOUBLE BoundaryCondition::d(Vector x){
//    DOUBLE pi=4.0*atan(1.0);
//    return sin(2*pi*x[0])*sin(pi*x[1])*sin(pi*x[2]);
//}


void LegendreSPECollocationSeparableEllipticProblem::getBoundaryValueReady( )
{
    int i, j, k;
//    int n=femspace[0]->getTrialFunction(0)->getPolynomialDegree();
//    LAGRANGEShapeFunction pTrial(n);
//    DOUBLE glp[n+1], wts[n+1];
//    Quadrature::LegendreGaussLobatto(n+1, glp, wts);

    pU1=new Matrix[polydeg+1];    pU2=new Matrix[polydeg+1];    pU3=new Matrix[polydeg+1];
    pLaplaceU1=new Matrix[polydeg+1];    pLaplaceU2=new Matrix[polydeg+1];    pLaplaceU3=new Matrix[polydeg+1];
    for (int i=0; i<polydeg+1; i++){
        pU1[i].setNM(polydeg+1, polydeg+1);    pU2[i].setNM(polydeg+1, polydeg+1);    pU3[i].setNM(polydeg+1, polydeg+1);
        pLaplaceU1[i].setNM(polydeg+1, polydeg+1);    pLaplaceU2[i].setNM(polydeg+1, polydeg+1);    pLaplaceU3[i].setNM(polydeg+1, polydeg+1);
    }

    Vector x(3);
    Matrix val1(polydeg+1, polydeg+1), val2(polydeg+1, polydeg+1), val3(polydeg+1, polydeg+1);
    Matrix val4(polydeg+1, polydeg+1), val5(polydeg+1, polydeg+1), val6(polydeg+1, polydeg+1);

//    for (i=0; i<polydeg+1; i++){
//        for (j=0; j<polydeg+1; j++){
//            x[0]=-1; x[1]=glp[j];  x[2]=glp[i];
//            val1[i][j]=coefficient_ptr[1]->d(x);
//            x[0]=1; x[1]=glp[j];  x[2]=glp[i];
//            val2[i][j]=coefficient_ptr[1]->d(x);
//
//            x[0]=glp[j]; x[1]=-1;  x[2]=glp[i];
//            val3[i][j]=coefficient_ptr[1]->d(x);
//            x[0]=glp[j]; x[1]=1;  x[2]=glp[i];
//            val4[i][j]=coefficient_ptr[1]->d(x);
//
//            x[0]=glp[j]; x[1]=glp[i];  x[2]=-1;
//            val5[i][j]=coefficient_ptr[1]->d(x);
//            x[0]=glp[j]; x[1]=glp[i];  x[2]=1;
//            val6[i][j]=coefficient_ptr[1]->d(x);
//        }
//    }
    INT nn = (polydeg+1)*(polydeg+1);
    INT index1[nn], index2[nn], index3[nn], index4[nn], index5[nn],index6[nn];

    LAGRANGE_3D_CUBE *trial=(LAGRANGE_3D_CUBE *)femspace[0]->getTrialFunction(0);
    trial->getFaceNodeIndex(5, index1);
    trial->getFaceNodeIndex(3, index2);
    trial->getFaceNodeIndex(2, index3);
    trial->getFaceNodeIndex(4, index4);
    trial->getFaceNodeIndex(0, index5);
    trial->getFaceNodeIndex(1, index6);

    for(i=0; i<polydeg+1; i++)
    {
        for(j=0; j<polydeg+1; j++)
        {
            k = i*(polydeg+1)+j;
            val1[i][j] = (*BoundaryValue)[index1[k]];
            val2[i][j] = (*BoundaryValue)[index2[k]];
            val3[i][j] = (*BoundaryValue)[index3[k]];
            val4[i][j] = (*BoundaryValue)[index4[k]];
            val5[i][j] = (*BoundaryValue)[index5[k]];
            val6[i][j] = (*BoundaryValue)[index6[k]];
        }
    }


    setBoundaryValue(0, val1);
    setBoundaryValue(1, val2);
    setBoundaryValue(2, val3);
    setBoundaryValue(3, val4);
    setBoundaryValue(4, val5);
    setBoundaryValue(5, val6);


}

// void LegendreSPECollocationSeparableEllipticProblem::setBoundaryValue(Vector* bv){
	// int start=8+(polydeg-1)*12+(polydeg-1)*(polydeg-1)*6;
// }

void LegendreSPECollocationSeparableEllipticProblem::computeU1U2andU3( )
{
    int i, j, k;
    int n=femspace[0]->getTrialFunction(0)->getPolynomialDegree();
    LAGRANGEShapeFunction pTrial(n);
    DOUBLE glp[n+1], wts[n+1];
    Quadrature::LegendreGaussLobatto(n+1, glp, wts);
    for (i=0; i<polydeg+1; i++){
        for (j=0; j<polydeg+1; j++){
            for (k=0; k<polydeg+1; k++){
                pU1[i][j][k]=(BoundaryValues[1][k][j]-BoundaryValues[0][k][j])/2*glp[i]+(BoundaryValues[1][k][j]+BoundaryValues[0][k][j])/2;
            }
        }
    }

    for (i=0; i<polydeg+1; i++){
        for (j=0; j<polydeg+1; j++){
            for (k=0; k<polydeg+1; k++){
                pU2[j][i][k] =(BoundaryValues[3][k][j]-BoundaryValues[2][k][j])/2*glp[i]+(BoundaryValues[1][k][j]+BoundaryValues[0][k][j])/2;
                pU2[j][i][k]-=(pU1[j][polydeg][k]-pU1[j][0][k])/2*glp[i]+(pU1[j][polydeg][k]+pU1[j][0][k])/2;
            }
        }
    }

    for (i=0; i<polydeg+1; i++){
        for (j=0; j<polydeg+1; j++){
            for (k=0; k<polydeg+1; k++){
                pU3[j][k][i] =(BoundaryValues[5][k][j]-BoundaryValues[4][k][j])/2*glp[i]+(BoundaryValues[5][k][j]+BoundaryValues[4][k][j])/2;
                pU3[j][k][i]-=(pU1[j][k][polydeg]-pU1[j][k][0])/2*glp[i]+(pU1[j][k][polydeg]+pU1[j][k][0])/2;
                pU3[j][k][i]-=(pU2[j][k][polydeg]-pU2[j][k][0])/2*glp[i]+(pU2[j][k][polydeg]+pU2[j][k][0])/2;
            }
        }
    }



}
void LegendreSPECollocationSeparableEllipticProblem::computelaplaceU_i( )
{
    int l, n, m, i, j, k;
    for (l=0; l<polydeg+1; l++){
        for (m=0; m<polydeg+1; m++){
            for (n=0; n<polydeg+1; n++){
                //��������ǵ���,ò��pLaplaceUi[l][m][n] = pLaplaceUi[l][n][m]
                for (i=0; i<polydeg+1; i++){
                    pLaplaceU1[l][m][n] += (*MLM[0])[l][i]*pU1[i][m][n] +\
                                           (*MLM[0])[m][i]*pU1[l][i][n] +\
                                           (*MLM[0])[n][i]*pU1[l][m][i];


                    pLaplaceU2[l][m][n] += (*MLM[0])[l][i]*pU2[i][m][n] +\
                                           (*MLM[0])[m][i]*pU2[l][i][n] +\
                                           (*MLM[0])[n][i]*pU2[l][m][i];


                    pLaplaceU3[l][m][n] += (*MLM[0])[l][i]*pU3[i][m][n] +\
                                           (*MLM[0])[m][i]*pU3[l][i][n] +\
                                           (*MLM[0])[n][i]*pU3[l][m][i];

                }
            }
        }
    }
}

void LegendreSPECollocationSeparableEllipticProblem::setRHSValue(Vector* rhs){
	int dof=femspace[0]->getTrialFunction(0)->degreeOfFreedom();
    INT ix[dof], iy[dof], iz[dof];
    LAGRANGE_3D_CUBE *trial=(LAGRANGE_3D_CUBE *)femspace[0]->getTrialFunction(0);
    trial->getFreedomTensorIndex(iy, ix, iz);
	int start=8+(polydeg-1)*12+(polydeg-1)*(polydeg-1)*6;
	
	for(INT z=0;z<polydeg-1;z++){
		for(INT i=start+z*(polydeg-1)*(polydeg-1);i<start+(z+1)*(polydeg-1)*(polydeg-1);i++){
			(*RHS[z])[ix[i]-1][iy[i]-1]=(*rhs)[i];
		}
	}
}

void LegendreSPECollocationSeparableEllipticProblem::computeRHS( ){
    int l, m, i, j, k, n=femspace[0]->getTrialFunction(0)->getPolynomialDegree();

    DOUBLE glp[polydeg+1], wts[polydeg+1];
    Quadrature::LegendreGaussLobatto(polydeg+1, glp, wts);
    Vector x(3);
    Matrix tmp[polydeg-1];
    for(i=1; i<polydeg; i++)
    {
        tmp[i-1].setNM(polydeg-1, polydeg-1);
        for (j=1; j<polydeg; j++)
        {
            for (k=1; k<polydeg; k++)
            {
                // tmp[i-1][j-1][k-1] = coefficient_ptr[0]->d(x)-\
                                     // pLaplaceU1[i][j][k] -\
                                     // pLaplaceU2[i][j][k] -\
                                     // pLaplaceU3[i][j][k] ;
				tmp[i-1][j-1][k-1] = (*RHS[k-1])[i-1][j-1]-\
                                     pLaplaceU1[i][j][k] -\
                                     pLaplaceU2[i][j][k] -\
                                     pLaplaceU3[i][j][k] ;
            }

        }
    }


    pRHSMat=new Matrix[polydeg-1];
    for (l=1; l<polydeg; l++){
        pRHSMat[l-1].setNM(polydeg-1, polydeg-1);
        for (j=1; j<polydeg; j++){
            for (k=1; k<polydeg; k++){
                pRHSMat[l-1][j-1][k-1]=0.0;
                for (i=1; i<polydeg; i++){
                    pRHSMat[l-1][j-1][k-1]+=tmp[i-1][j-1][k-1]*(*MLM[1])[l-1][i-1];
                }
            }
        }
        pRHSMat[l-1]=(*MLM[1])*pRHSMat[l-1]*MLM[1]->transpose();
    }
}

void LegendreSPECollocationSeparableEllipticProblem::computeLocalMatrices(){
    int n=femspace[0]->getTrialFunction(0)->getPolynomialDegree();
    LAGRANGEShapeFunction pTrial(n);

    DOUBLE glp[n+1], wts[n+1];
    Quadrature::LegendreGaussLobatto(n+1, glp, wts);
    Vector coord(n+1);    coord=glp;
    pTrial.setNodePointCoord(coord);
    pTrial.computeCoefficient();
    Vector xi(1), WR, WI;
    Matrix VL(n-1, n-1), VR(n-1, n-1);
    Matrix val;

    MLM[0]=new Matrix(n+1, n+1);
    for (int i=0; i<n+1; i++){
        xi[0]=glp[i];
        pTrial.hessian_phi(xi, val);
        for (int j=0; j<n+1; j++){
            (*MLM[0])[i][j]=-val[0][j];
        }
    }

    LAPACK_INTERFACE interface;
    Matrix mathbbS(n-1, n-1);
    MLM[0]->getSubMatrix(1,1,  n-1,n-1, mathbbS);
    interface.Lapack_dgeev_(mathbbS, WR, WI, VL, VR);
    MLM[1]=new Matrix(VR.inverse());
    MLM[2]=new Matrix(VR);
    eigenvalues=WR;

}


void LegendreSPECollocationSeparableEllipticProblem::imposeBoundaryCondition(){
    int i, j, k;

}

void LegendreSPECollocationSeparableEllipticProblem::solve(){
    setNMLM(3);
    setNSolution(2);
    int l, n, m, i, j, k;
    //tic();
    computeLocalMatrices();
    getBoundaryValueReady();
    computeU1U2andU3( );
    computelaplaceU_i();
   // toc();
//    tic();
    computeRHS();
    imposeBoundaryCondition();

//    toc();
    Matrix val[polydeg-1], ual[polydeg-1];
    for (l=0; l<polydeg-1; l++){
        val[l].setNM(polydeg-1, polydeg-1);
        for (n=0; n<polydeg-1; n++){
            for (m=0; m<polydeg-1; m++){
                val[l][n][m]=pRHSMat[l][n][m]/(eigenvalues[l]+eigenvalues[n]+eigenvalues[m]);
            }
        }
    }
    //V_l(l,j,k) = E(l,i)*V(i,j,k)    U_l = E*V_l*E.T
//    for (l=0; l<polydeg-1; l++){
//        ual[l].setNM(polydeg-1, polydeg-1);
//        for (j=0; j<polydeg-1; j++){
//            for (k=0; k<polydeg-1; k++){
//                for (i=0; i<polydeg-1; i++){
//                    ual[l][j][k]=val[i][j][k]*(*MLM[2])[l][i];
//                }
//            }
//        }
//        ual[l]=(*MLM[2])*ual[l]*MLM[2]->transpose();
//    }

    //ֱ����������Ķ�����ǶԵ�
    for (l=0; l<polydeg-1; l++){
        ual[l].setNM(polydeg-1, polydeg-1);
        for (n=0; n<polydeg-1; n++){
            for (m=0; m<polydeg-1; m++){
                for (j=0; j<polydeg-1; j++){
                    for (k=0; k<polydeg-1; k++){
                        for (i=0; i<polydeg-1; i++){
                            ual[l][m][n]+=val[i][j][k]*(*MLM[2])[l][i]*(*MLM[2])[m][j]*(*MLM[2])[n][k];
                        }
                    }
                }
            }
        }
    }



    int dof=femspace[0]->getTrialFunction(0)->degreeOfFreedom();
    INT ix[dof], iy[dof], iz[dof];
    LAGRANGE_3D_CUBE *trial=(LAGRANGE_3D_CUBE *)femspace[0]->getTrialFunction(0);
    trial->getFreedomTensorIndex(iy, ix, iz);
    solution[0]=new Vector(dof);
    solution[1]=new Vector(dof);
    int start=8+(polydeg-1)*12+(polydeg-1)*(polydeg-1)*6;
	
	// for(INT i=0;i<start;i++){
		// (*solution[0])[i]=(*BoundaryValue)[i];
	// }
	
	
	
//    tic();
    for (int ii=start; ii<dof; ii++){
        l=ix[ii];  n=iy[ii];  m=iz[ii];
        (*solution[0])[ii]=ual[l-1][n-1][m-1];
    }
    //��������ط��е�ͷ�Σ�ҪС��С��~��������
    INT index[dof];
    CGFEMSpace *cgfemspace = (CGFEMSpace *)femspace[0];
    cgfemspace->getGlobalIndex(0, index);
    //��������index�ǳ��ؼ���~~������
    for (int ii=0; ii<dof; ii++){
        l=ix[ii];  n=iy[ii];  m=iz[ii];
        (*solution[0])[index[ii]] += pU1[l][n][m]+pU2[l][n][m]+pU3[l][n][m];
    }
	
	// for(INT i=0;i<dof;i++){
		// cout<<iy[i]<<"  "<<ix[i]<<" "<<iz[i]<<endl;
	// }

}
