#ifndef LEGENDRE_SPECTRAL_COLLOCATION_METHOD_FOR_SEPARABLE_ELLIPTIC_EQUATION_H
#define LEGENDRE_SPECTRAL_COLLOCATION_METHOD_FOR_SEPARABLE_ELLIPTIC_EQUATION_H

#include "FEMProblem.h"
#include "lagrange3Dsf.h"
#include "lapack_interface.h"

//class RHSFunc : public Coefficient{
//
//public:
//    virtual DOUBLE d(Vector x);
//};
//
//class BoundaryCondition : public Coefficient{
//
//public:
//    virtual DOUBLE d(Vector x);
//};

class LegendreSPECollocationSeparableEllipticProblem : public FEMProblem{
    int polydeg;
    Matrix BoundaryValues[6];
    Matrix *pRHSMat, *pU1, *pU2, *pU3, *pLaplaceU1, *pLaplaceU2, *pLaplaceU3;
    Vector eigenvalues, *BoundaryValue;
	Matrix** RHS;
public:
    LegendreSPECollocationSeparableEllipticProblem(FEMSpace *fs, Quadrature *quad) : FEMProblem(fs, quad){
        coefficient_ptr   =new Coefficient *[6];
//        coefficient_ptr[0]=new RHSFunc;
//        coefficient_ptr[1]=new BoundaryCondition;
        polydeg=femspace[0]->getTrialFunction(0)->getPolynomialDegree();
		
		RHS=new Matrix* [polydeg-1];
		for(INT i=0;i<polydeg-1;i++){
			RHS[i]=new Matrix(polydeg-1,polydeg-1);
		}
		
		BoundaryValue=NULL;

        pRHSMat=NULL;   pLaplaceU1=NULL;    pLaplaceU2=NULL;   pLaplaceU3=NULL;
        pU1=NULL;     pU2=NULL;    pU3=NULL;
    }

    ~LegendreSPECollocationSeparableEllipticProblem(){
        delete coefficient_ptr[0];
        delete coefficient_ptr[1];

        delete []pRHSMat;
        delete []pLaplaceU1;
        delete []pLaplaceU2;
        delete []pLaplaceU3;
        delete []pU1;
        delete []pU2;
        delete []pU3;
    }

    Coefficient *getExactSolution(){
        return coefficient_ptr[1];
    }
//    Coefficient *getCoefficient(int i){
//        return coefficient_ptr[i];
//    }
    void setBoundaryValue(int bindex, Matrix &mat){
        BoundaryValues[bindex]=mat;
    }
    void setBoundaryValue(Vector *bv){BoundaryValue = bv;};
    void getBoundaryValueReady();
	
	void setRHSValue(Vector* rhs);

    virtual void computeRHS( );
    virtual void computelaplaceU_i();
    virtual void computeU1U2andU3();
    virtual void computeLocalMatrices();

    virtual void imposeBoundaryCondition();

    virtual void solve();

};

typedef LegendreSPECollocationSeparableEllipticProblem LSPECSEP;
typedef LegendreSPECollocationSeparableEllipticProblem * PLSPECSEP;
#endif // LEGENDRE_SPECTRAL_COLLOCATION_METHOD_FOR_SEPARABLE_ELLIPTIC_EQUATION_H
