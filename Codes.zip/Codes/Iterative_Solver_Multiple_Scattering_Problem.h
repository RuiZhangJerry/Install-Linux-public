#ifndef ITERATIVE_SOLVER_MULTIPLE_SCATTERING_PROBLEM_H_INCLUDED
#define ITERATIVE_SOLVER_MULTIPLE_SCATTERING_PROBLEM_H_INCLUDED

/********************************************************************
*         HELMHLOTZ equations with varialbe coefficient
*         SPECTRAL GALERKIN method
*********************************************************************/
//#include "SE_Helmholtz_eq_ellip.h"
//#include "eva_ellip_scattering.h"

#include "SE_var_coefficient_HELMHOLTZ_Eq_def.h"
#include "fourier_spectral_time_harmonic_acoustic_wave_scattering2D.h"

class GeneralScalarCoefficient : public Coefficient{

public:
	virtual DOUBLE d(Vector x);
};

class ReGeneralBoundaryCondition : public Coefficient{
	DOUBLE kn;
public:
	ReGeneralBoundaryCondition(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);

};

class ImGeneralBoundaryCondition : public Coefficient{
	DOUBLE kn;
public:
	ImGeneralBoundaryCondition(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);

};

class GeneralBoundaryCondition:public Coefficient{
	DOUBLE kn;
	public:
		GeneralBoundaryCondition(DOUBLE a){
			kn=a;
		}
		virtual Complex c(Vector x);
};

class IterativeSolverMulScatProblem: public FEMProblem {
    int nScatterers;    //ɢ�������
    int NBP;
    DOUBLE GammaR;
    INT *NP;
    Grid ** GArray;     //ÿ��ɢ���������Ӧ������
    Quadrature **QuadArray;
    LAGRANGE_2D_SQUARE ** TrialArray;
    // ellip_SpectralElementSpace **SESpaceArray;
    SpectralElementSpace **SESpaceArray;
    Coefficient **coefficient_ptr;  //Ҫ������ ��FEMproblem.h�����������������̳���Ҫ������
	
	Complex** FourierCoeff;

    Vector** ValonScatter;Vector** ValonAB; Vector** TValonScatter; Vector** ScatterVal;
    Matrix** CoorofScatter;

protected:

	//SE_VariableCoefficientHELMHLOTZProblem **LocalSolver;
    //Mathieu_Expansion **LocalExpansion;
    //eval_ellip_scattering** LocalCalculate;

    SE_VariableCoefficientHELMHLOTZProblem **LocalSolver;
    Fourier_Expansion *Expansion;
    FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM *Extension;

public:
	IterativeSolverMulScatProblem(int nS, int *polydeg) {
        GammaR=sqrt(2.0);
        nScatterers=nS;
        NP=new INT[nS];
	    GArray=new Grid*[nS];
	    QuadArray=new Quadrature*[nS];
	    TrialArray=new LAGRANGE_2D_SQUARE *[nS];
	    //SESpaceArray=new ellip_SpectralElementSpace *[nS];
        SESpaceArray=new SpectralElementSpace *[nS];
	    LocalSolver=new SE_VariableCoefficientHELMHLOTZProblem *[nS];
        //LocalExpansion=new Mathieu_Expansion* [nS];
        
        ValonScatter=new Vector* [nS];
        ValonAB=new Vector* [nS];
        TValonScatter=new Vector* [nS];
        CoorofScatter=new Matrix* [nS];
        ScatterVal=new Vector* [nS];
		FourierCoeff=new Complex* [nS];
        for (int i=0; i<nS; i++){
            GArray[i]=new Grid();
            GArray[i]->readGrid("spectralgrid1.dat", 4);
        }
        DOUBLE *x;
		for (int ii=0;ii<1;ii++){
			for(int jj=0;jj<2;jj++){
               for (int j=0; j<GArray[(ii*1)+jj]->getNVertex(); j++){
                  x=GArray[(ii*1)+jj]->getVertex(j)->getCoord();
                  x[0]=x[0]+2.2*jj;
				  x[1]=x[1]+2.2*ii;
			   }
			}
        }
        for (int i=0; i<nS; i++){
            SESpaceArray[i]=new SpectralElementSpace(GArray[i]);
            SESpaceArray[i]->setGrid(GArray[i]);    //�ڶ�ɢ����ɢ���������������Ҫ�ı�ģ�����������Կ�ʼ����������


            QuadArray[i]=new Quadrature(RECTANGLE, GAUSS_LOBATTAO_QUADRATURE);
            QuadArray[i]->permuteData(polydeg[i]);


            TrialArray[i]=new LAGRANGE_2D_SQUARE(polydeg[i]-1);
            DOUBLE glp[polydeg[i]], wts[polydeg[i]];
            Quadrature::LegendreGaussLobatto(polydeg[i], glp, wts);
            Vector coord(polydeg[i]);
            coord=glp;
            TrialArray[i]->setNodePointCoord(coord);
            TrialArray[i]->computeCoefficient();

            SESpaceArray[i]->setQuadrature(QuadArray[i]);        //!!! Be caution !!!//
            SESpaceArray[i]->setNTrialFunction(1);
            SESpaceArray[i]->setNTestFunction(1);
            SESpaceArray[i]->setTestFunction(TrialArray[i],  0); //!!! Be caution !!!//
            SESpaceArray[i]->setTrialFunction(TrialArray[i], 0);

            SESpaceArray[i]->formSpace();

            LocalSolver[i]=new SE_VariableCoefficientHELMHLOTZProblem(SESpaceArray[i], QuadArray[i]);   //׼����ɢ�����������
            
            ValonScatter[i]=new Vector;
            ScatterVal[i]=new Vector;
            ValonAB[i]=new Vector;
            TValonScatter[i]=new Vector;
            CoorofScatter[i]=new Matrix;
        }

        Expansion=new Fourier_Expansion(GArray[0],10,50);
        Extension=new FSTHAWSP(50,1.0,10.0);

        DOUBLE kn=10.0;
        coefficient_ptr=new Coefficient *[3];
		coefficient_ptr[0]=new GeneralScalarCoefficient;
		coefficient_ptr[1]=new ReGeneralBoundaryCondition(kn);     //���������������
		coefficient_ptr[2]=new ImGeneralBoundaryCondition(kn);
	}

	// ~IterativeSolverMulScatProblem(){
	// 	// delete coefficient_ptr[0];
	// 	// delete coefficient_ptr[1];
	// 	// delete coefficient_ptr[2];
	// }

    void solve();

    Vector GetCenterCoord(INT i);

    
    virtual Vector globalMatrixProdVector(const Vector &vv);

	void getGeneralBoundaryRHS(Vector &GeneralBoundaryRHS);

    Complex ComputeScatteringField(Vector x);

    void DrawPatch(ofstream &output, int solverindex, INT refine);
    void outputTecPlotDataFile(const char *filename);
    void outputPlot(const char *filename, INT refine);
	
	//void Arnodi_Decomposition(INT k, Matrix &Hk, Matrix &H, Matrix &h);
    //void Multiorthognal_Arnodi_Decomposition(INT k, Matrix &Vk,Matrix &H,Matrix &h,Matrix &RF);//This technique is better than
                                                         // Arnordi_Decompsition!-)
    //void ReMultiorthogonal_Arnodi_Decomposition(INT k, Matrix INIT,Matrix &Vk, Matrix &H, Matrix &h);

    //void Produce_Givens(DOUBLE a, DOUBLE b, DOUBLE &c, DOUBLE &s);
    //void QR_Decomposition(Matrix A, Matrix RF, Matrix &Q, Matrix &R, Matrix &RFk);
    //void Least_Square_Sol(Matrix A, Matrix g, Matrix &Sol);
    //void GMRES_Iteration(Vector &BoundaryVal);
    //void GMRESm_Iteration();
    //void PPNiteration(Vector &BoundaryVal);

};

typedef IterativeSolverMulScatProblem ISMSP;
typedef IterativeSolverMulScatProblem * PISMSP;


#endif // ITERATIVE_SOLVER_MULTIPLE_SCATTERING_PROBLEM_H_INCLUDED
