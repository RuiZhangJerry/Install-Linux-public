#ifndef SHE_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_H
#define SHE_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_H

#include "fourier_expansion_problem.h"
#include "ufunc.h"
#include "cmatrix.h"
//#include "CM_forbesselratio.h"

using namespace std;

class IncidentWave:public Coefficient{             // incident wave class
    Vector PropVec;                  // propagating vector.
    DOUBLE R;                  // the radius of the spherical scatter
public:
    IncidentWave(Vector wv, DOUBLE Radius){
        PropVec=wv;
        R=Radius;
    }

    void setRadius(DOUBLE Radius){
        R=Radius;
    }

    DOUBLE getRadiusOfScatter(){
        return R;
    }

    Vector getPropagationVectorOfIncidentWave(){
        return PropVec;
    }

    virtual Complex c(Vector x){
        DOUBLE t=PropVec*x;
        //Complex cc(cos(t), sin(t));
    	Complex cc(gsl_sf_bessel_J0 (10.0*sqrt(x.norm())),gsl_sf_bessel_Y0 (10.0*sqrt(x.norm())));
        return cc;
    
	//return gsl_sf_bessel_J0 (5.0*sqrt(x.norm()));
    }
};

class FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM{

    int nFourier;     // trucate number for l in the spherical harmonic expansion
    DOUBLE wavenumber;
    DOUBLE scatterRadia;
    DOUBLE outerRadia;
    Fourier_Expansion *expansion;
    Vector* nodesvalue;
    Complex* FourierCoeff;
    Vector MoveVectorex;

public:
    FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM(){
        nFourier=0;
        expansion=NULL;
    }

    FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM(INT N,DOUBLE r, DOUBLE kn){
        nFourier=N;
        FourierCoeff=NULL;

        scatterRadia=r;
        outerRadia=0.0;
        wavenumber=kn;

        MoveVectorex.setDim(2);

        
    }
    ~FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM(){  
    }

    void setCenterCoord(Vector v){MoveVectorex=v; }
    void setOuterBdry(DOUBLE R){outerRadia=R; }

    void setFourierCoeff(Complex* v){
        FourierCoeff=v;
    }

    //void computeScatteringField(IncidentWave * ui);
    Complex computeDhankel(INT n,DOUBLE r,DOUBLE k);
	
	Vector getMoveVectorex(){
		return MoveVectorex;
	}

    Complex evalScatteringField(Vector x);

    void outputTecPlotDataFile(const char *filename, DOUBLE R1, DOUBLE R2, INT N);

};
typedef FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM   FSTHAWSP;
typedef FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM* PFSTHAWSP;
#endif // SHE_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING3D_H
