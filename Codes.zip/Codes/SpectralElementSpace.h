#ifndef SPECTRALELEMENTSPACE_H
#define SPECTRALELEMENTSPACE_H

#include "FEMSpace.h"
#include "ufunc.h"


class InnerBdryParameterForm: public Coefficient{
public:
	virtual Vector v(Vector x);
};

class OuterBdryParameterForm: public Coefficient{
public:
	virtual Vector v(Vector x);
};

class DiffInnerBdryParameterForm: public Coefficient{
public:
	virtual Vector v(Vector x);
};

class DiffOuterBdryParameterForm: public Coefficient{
public:
	virtual Vector v(Vector x);
};




class SpectralElementSpace : public CGFEMSpace{
	Vector MoveVector;
	Coefficient** Coefficient_ptr;

public:
    SpectralElementSpace(Grid* grid){
    	MoveVector.setDim(2);
        INT nPatch=grid->getBoundaryPatch(1)->getNEdge( );
        MoveVector.setDim(2);MoveVector=0.0;
        for(INT i=0;i<grid->getBoundaryPatch(1)->getNVertex();i++){
            MoveVector[0]+=(grid->getBoundaryPatch(1)->getVertex(i)->getCoord())[0];
            MoveVector[1]+=(grid->getBoundaryPatch(1)->getVertex(i)->getCoord())[1];
        }
        MoveVector[0]=MoveVector[0]/nPatch;
        MoveVector[1]=MoveVector[1]/nPatch;

        Coefficient_ptr=new Coefficient* [4];
        Coefficient_ptr[0]=new InnerBdryParameterForm();
        Coefficient_ptr[1]=new OuterBdryParameterForm();
        Coefficient_ptr[2]=new DiffInnerBdryParameterForm();
        Coefficient_ptr[3]=new DiffOuterBdryParameterForm();
    	
    }

    ~SpectralElementSpace(){
    	delete[] Coefficient_ptr;
    }

    Vector getMoveVector(){
    	return MoveVector;
    }

    virtual Vector mapping(INT i, Vector &lambda);

    virtual DOUBLE jacobi(INT i, Vector &lambda);

    virtual Matrix JM(INT i, Vector &lambda);

    virtual Matrix JMIT(INT i, Vector &lambda);

    virtual Vector inverseMapping(INT i, Vector &x);
    // compute L2 error of the i-th solution with the exact function f
//    virtual DOUBLE L2Error(Coefficient *f, Vector &uh);
//    DOUBLE  L2ErrorOfGrad(Coefficient *f, Vector &uh);

};

#endif // SPECTRALELEMENTSPACE_H
