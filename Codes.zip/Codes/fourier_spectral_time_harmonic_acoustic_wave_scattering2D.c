#include "fourier_spectral_time_harmonic_acoustic_wave_scattering2D.h"
void FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM::outputTecPlotDataFile(const char *filename, DOUBLE R1, DOUBLE R2, INT N){
    INT i, j, k;
    DOUBLE r, theta, pi=4.0*atan(1.0);
    ofstream output(filename);
    output<<"TITLE = \"Example: Simple XY Plot\""<<endl;
    output<<"VARIABLES = \"X\", \"Y\", \"u\""<<endl;

    Vector kv(2);
    kv(1)=10.0;  kv(2)=10.0;
    IncidentWave *f=new IncidentWave(kv, 0.5);

    Matrix coord(2, (N+1)*(N+1));
    DOUBLE dx=2.0/N;
    k=0;
    for (i=0; i<N+1; i++){
        for (j=0; j<N+1; j++){
            coord[0][k]=j*dx-1.0;
            coord[1][k]=i*dx-1.0;
            k++;
        }
    }
    int eledof=(N+1)*(N+1);
    int nRow=N;
    Vector x(2), lambda(2),mu(2);
    for (i=0; i<4; i++){
        output<<"ZONE T=\""<<i<<"\","<<"N="<<eledof<<","<<"E="<<nRow*nRow<<","<<"ET=quadrilateral, F=FEPOINT"<<endl;
        for (j=0; j<eledof; j++){
            lambda[0]=coord[0][j]; lambda[1]=coord[1][j];
            r=(R2-R1)/2*lambda[1]+(R2+R1)/2;
            theta=pi/4.0*lambda[0]+pi*(i+1)/2.0;
            mu[0]=r;  mu[1]=theta;
           
            x[0]=r*cos(theta)+MoveVectorex[0];  x[1]=r*sin(theta)+MoveVectorex[1];
            //f->setRadius(r);
            Complex inc=f->c(x);
            output<<setprecision(15)<<setw(20)<<x[0]<<"\t";
            output<<setprecision(15)<<setw(20)<<x[1]<<"\t";
            output<<setprecision(15)<<setw(20)<<evalScatteringField(mu).rp()<<endl;
        }
        for (j=0; j<nRow; j++){
            for (k=0; k<nRow; k++){
                INT ic=j*(nRow+1)+k+1;
                output<<setw(10)<<ic<<"\t";
                output<<setw(10)<<ic+1<<"\t";
                output<<setw(10)<<ic+nRow+2<<"\t";
                output<<setw(10)<<ic+nRow+1<<endl;
            }
        }
    }
    output.close();
    return;
}

Complex FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM::computeDhankel(INT n,DOUBLE r,DOUBLE k){
    Complex val,dval;
    val.rp()=gsl_sf_bessel_Jn(n,k*1.0*scatterRadia);
    val.ip()=gsl_sf_bessel_Yn(n,k*1.0*scatterRadia);
    dval.rp()=gsl_sf_bessel_Jn(n,k*1.0*r);
    dval.ip()=gsl_sf_bessel_Yn(n,k*1.0*r);
    return dval/val;
}

Complex FS_TIME_HARMONIC_ACOUSTIC_WAVE_SCATTERING2D_PROBLEM::evalScatteringField(Vector x){
    int n;
    DOUBLE r, theta;
    r=x[0];  theta=x[1];

    // if(r<scatterRadia){
    //     cout<<"??? Error: ===> Radial ERROR! "<<endl;
    //     exit(1);
    // }

    Complex us,fe,etheta;
    for (n=0; n<=nFourier; n++){
        etheta.rp()=cos(n*1.0*theta);
        etheta.ip()=sin(n*1.0*theta);
        fe=computeDhankel(n,r,wavenumber);
        us=us+FourierCoeff[nFourier+n]*fe*etheta;
    }
    for(n=1; n<nFourier; n++){
	etheta.rp()=cos((-n)*1.0*theta);
	etheta.ip()=sin((-n)*1.0*theta);
        fe=computeDhankel(-n,r,wavenumber);
        us=us+FourierCoeff[nFourier-n]*fe*etheta;
    }

    return us;
}
