#include "Iterative_Solver_Multiple_Scattering_Problem.h"
//#include "SE_var_coefficient_HELMHOLTZ_Eq_def.h"

DOUBLE GeneralScalarCoefficient::d(Vector x){
    return 1.0;
}


DOUBLE ReGeneralBoundaryCondition::d(Vector x){
	//return cos(5.0*x[0]+sqrt(75)*x[1]);
   return cos(kn*x[1]);
   // DOUBLE r=sqrt(x[0]*x[0]+x[1]*x[1]);
   // return gsl_sf_bessel_J0 (kn*r);

}
DOUBLE ImGeneralBoundaryCondition::d(Vector x){
	//return sin(5.0*x[0]+sqrt(75)*x[1]);
    return sin(kn*x[1]);
    // DOUBLE r=sqrt(x[0]*x[0]+x[1]*x[1]);
    // return gsl_sf_bessel_Y0 (kn*r);
}

Complex GeneralBoundaryCondition::c(Vector x){
	Complex cc;
	// cc.rp()=cos(5.0*x[0]+sqrt(75)*x[1]);
	// cc.ip()=sin(5.0*x[0]+sqrt(75)*x[1]);
	cc.rp()=cos(kn*x[1]);
	cc.ip()=sin(kn*x[1]);
	return cc;
}

Vector IterativeSolverMulScatProblem::GetCenterCoord(INT i){
	Vector CenterCoord(2);
	for(INT j=0;j<GArray[i]->getBoundaryPatch(0)->getNVertex();j++){
		CenterCoord[0]+=((GArray[i]->getBoundaryPatch(0)->getVertex(j)->getCoord())[0]);
		CenterCoord[1]+=((GArray[i]->getBoundaryPatch(0)->getVertex(j)->getCoord())[1]);
	}
	
	return CenterCoord/(GArray[i]->getBoundaryPatch(0)->getNVertex());
}

void IterativeSolverMulScatProblem::getGeneralBoundaryRHS(Vector &GeneralBoundaryRHS){
	GeneralBoundaryRHS.setDim(2*NBP);
	INT nBoundaryNodes[nScatterers];
	Matrix BoundaryCoord[nScatterers];
	Vector x(2);
	
	for(INT i=0;i<nScatterers;i++){
		LocalSolver[i]->getBoundaryInf();
		nBoundaryNodes[i]=LocalSolver[i]->getNB();
		LocalSolver[i]->getbpcoord(BoundaryCoord[i]);
	}
	
	for(INT i=0;i<nScatterers;i++){
		for(INT j=0;j<nBoundaryNodes[i];j++){
			x[0]=(BoundaryCoord[i])[j][0];
			x[1]=(BoundaryCoord[i])[j][1];
			GeneralBoundaryRHS[j+i*nBoundaryNodes[i]    ]=coefficient_ptr[1]->d(x); //Be Caution! we assume the local meshes are identity!-)
			GeneralBoundaryRHS[j+i*nBoundaryNodes[i]+NBP]=coefficient_ptr[2]->d(x);
		}
	}
	//cout<<GeneralBoundaryRHS<<endl;
}


Vector IterativeSolverMulScatProblem::globalMatrixProdVector(const Vector& vv){
	INT dim=vv.getDim();
	if(dim!=2*NBP){
		cout<<"??? Error: ===> Dimension ERROR! "<<endl;
		exit(1);
	}
	Vector v=vv;
	
	for(INT i=0; i<nScatterers; i++){//Initial some value!-)
		LocalSolver[i]->getBoundaryInf();
		(*(ValonScatter[i])).setDim(2*(LocalSolver[i]->getNB()));
		(*(ValonAB[i])).setDim(2*(LocalSolver[i]->getNB()));
		(*(TValonScatter[i])).setDim(2*(LocalSolver[i]->getNB()));
		(*CoorofScatter[i]).setDim(2*(LocalSolver[i]->getNB()),2);
		(*ScatterVal[i]).setDim(2*(LocalSolver[i]->getNB()));
		for(INT j=0;j<(LocalSolver[i]->getNB());j++){
			(*(ValonScatter[i]))[j]=v[j+i*(LocalSolver[i]->getNB())];
			(*(ValonScatter[i]))[j+(LocalSolver[i]->getNB())]=v[j+i*(LocalSolver[i]->getNB())+NBP];
			(*(TValonScatter[i]))[j]=v[j+i*(LocalSolver[i]->getNB())];
			(*(TValonScatter[i]))[j+(LocalSolver[i]->getNB())]=v[j+i*(LocalSolver[i]->getNB())+NBP];
		}
		LocalSolver[i]->setBoundaryVal(*(ValonScatter[i]));
		LocalSolver[i]->solve();
		
		LocalSolver[i]->getbpcoord(*(CoorofScatter[i]));
		LocalSolver[i]->evalArtificialBoundaryValue();
		*ValonAB[i]=(*LocalSolver[i]->getArtificialBoundaryValue());	
		
		// Expansion->setnodesval(ValonAB[i]);
		// Expansion->computeFourierCplx_disc();
		// FourierCoeff[i]=Expansion->getFourierCoefficients();
	}
	
	Vector x,MoveVector,polar(2);
	x.setDim(2);
	MoveVector.setDim(2);
	for(INT i=0;i<nScatterers;i++){
		for(INT j=0;j<i;j++){
			MoveVector=GetCenterCoord(j);
			Expansion->setnodesval(ValonAB[j]);
			Expansion->computeFourierCplx_disc();
			Complex* pFCoeff=Expansion->getFourierCoefficients();
			
			//Extension->setFourierCoeff(FourierCoeff[j]);
			Extension->setFourierCoeff(pFCoeff);
			for(INT jj=0;jj<(LocalSolver[i]->getNB());jj++){
				x[0]=(*(CoorofScatter[i]))[jj][0];
				x[1]=(*(CoorofScatter[i]))[jj][1];
				cartTopolar(x[0]-MoveVector[0],x[1]-MoveVector[1],polar[0],polar[1]);
				
				Complex temval=Extension->evalScatteringField(polar);
				(*(ScatterVal[i]))[jj]=temval.rp();
				(*(ScatterVal[i]))[jj+(LocalSolver[i]->getNB())]=temval.ip();
			}
			*(TValonScatter[i])=(*(TValonScatter[i]))+(*(ScatterVal[i]));
		}
		for(INT j=i+1;j<nScatterers;j++){
			MoveVector=GetCenterCoord(j);
			Expansion->setnodesval(ValonAB[j]);
			Expansion->computeFourierCplx_disc();
			Complex* pFCoeff1=Expansion->getFourierCoefficients();
			// Extension->setFourierCoeff(FourierCoeff[j]);
			Extension->setFourierCoeff(pFCoeff1);
			for(INT jj=0;jj<(LocalSolver[i]->getNB());jj++){
				x[0]=(*(CoorofScatter[i]))[jj][0];
				x[1]=(*(CoorofScatter[i]))[jj][1];
				cartTopolar(x[0]-MoveVector[0],x[1]-MoveVector[1],polar[0],polar[1]);
				Complex temval1=Extension->evalScatteringField(polar);
				(*(ScatterVal[i]))[jj]=temval1.rp();
				(*(ScatterVal[i]))[jj+(LocalSolver[i]->getNB())]=temval1.ip();
			}
			*(TValonScatter[i])=(*(TValonScatter[i]))+(*(ScatterVal[i]));
		}
	}

	Vector TV;
	TV.setDim(2*NBP);
	for(INT i=0;i<nScatterers;i++){
		for(INT j=0;j<LocalSolver[i]->getNB();j++){
			TV[j+i*(LocalSolver[0]->getNB())    ]=((*TValonScatter[i]))[j];//Caution! We first suppose every local meshes are identify!-) 
			TV[j+i*(LocalSolver[0]->getNB())+NBP]=((*TValonScatter[i]))[j+LocalSolver[i]->getNB()];
		}
	}

	return TV;
}

void IterativeSolverMulScatProblem::solve(){
	NBP=0;
    Vector TEM;
    for(INT i=0; i<nScatterers;i++){   //Obtain the sum of all points on boundaries of the whole scatterers!-)
    	LocalSolver[i]->getBoundaryInf();
    	NP[i]=LocalSolver[i]->getNB();
    	NBP+=NP[i];
	}



	//DOUBLE *x=GArray[0]->getBoundaryPatch(1)->getEdge(0)->getVertex(0)->getCoord();
	//cout<<x[0]<<"  "<<x[1]<<endl;
	// LocalSolver[0]->INIT_solve();
	// PVector uhre=LocalSolver[0]->getSolution(0);
	// SESpaceArray[0]->outputTecPlotDataFile("Reuhplot.dat", *uhre, 20);
	// LocalSolver[0]->evalArtificialBoundaryValue();


	// Vector val=(*(LocalSolver[0]->getArtificialBoundaryValue()));

	// Fourier_Expansion* exp=new Fourier_Expansion(GArray[0],10,50);
	// PFSTHAWSP extend=new FSTHAWSP(50,sqrt(2),5.0);
	// Vector v=GetCenterCoord(0);
	// extend->setCenterCoord(v);
	// extend->setOuterBdry(3.0);

	
	// //for(int i=0;i<5;i++){
	// exp->setnodesval(&val);
	// exp->computeFourierCplx_disc();
	// Complex* coeff=exp->getFourierCoefficients();
	// //cout<<coeff[0]<<endl;
	 
	//  extend->setFourierCoeff(coeff);

	//  extend->outputTecPlotDataFile("scaterfield.dat", sqrt(2.0), 3.0, 20);
	//}
//	Matrix bp;
//	LocalSolver[0]->getbpcoord(bp);
//	cout<<bp<<endl;



	// cout<<NBP<<endl;
	Vector BoundaryRHS;
	Vector v(2*NBP);  v=0.0;
	getGeneralBoundaryRHS(BoundaryRHS);

	int restart=50, MAX_ITER=5000;
	DOUBLE tol=1.0e-12;
	


	matrixFreePGMRES(1, v, BoundaryRHS,restart, MAX_ITER, tol,1);
	//cout<<v<<endl;
	cout<<MAX_ITER<<endl;
	cout<<tol<<endl;
    
	// PVector u=new Vector [nScatterers];
	
	// for(INT i=0;i<nScatterers;i++){
	// 	u[i].setDim(NBP/nScatterers*2);
	// 	for(INT ii=0;ii<NBP/nScatterers;ii++){
	// 		(u[i])[ii]=v[ii+(NBP/nScatterers)*i];
	// 		(u[i])[ii+NBP/nScatterers]=v[ii+(NBP/nScatterers)*i+NBP];
	// 	}
	// 		LocalSolver[i]->setBoundaryVal(u[i]);
	// 		LocalSolver[i]->solve();
	// 		LocalSolver[i]->evalArtificialBoundaryValue();
			
	// }


		
}

Complex IterativeSolverMulScatProblem::ComputeScatteringField(Vector x){
	Complex scatteringfield =0.0;
	DOUBLE rl,rr,thetal,thetar, r,theta;
	Vector mvl(2), mvr(2), ABvall,ABvalr;
    mvl=GetCenterCoord(0);
    mvr=GetCenterCoord(1);
    
    cartTopolar(x[0]-mvl[0],x[1]-mvl[1],rl,thetal);
    cartTopolar(x[0]-mvr[0],x[1]-mvr[1],rr,thetar);
    //cout<<rl<<"	"<<rr<<endl;
    //if((rl-1.0)*(rr-1.0)<0.0){
    	//scatteringfield=0.0;
	//}
	ABvall=(*(LocalSolver[0]->getArtificialBoundaryValue()));
	ABvalr=(*(LocalSolver[1]->getArtificialBoundaryValue()));
	
	//if((rl-1.0)>=0.0&&(rr-1.0)>=0.0){
		Expansion->setnodesval(&ABvall);
		Expansion->computeFourierCplx_disc();
		Complex* pFCoeff=Expansion->getFourierCoefficients();
		Extension->setFourierCoeff(pFCoeff);
		Vector polar(2);
		polar[0]=rl;  polar[1]=thetal;
		scatteringfield=Extension->evalScatteringField(polar);
		
		Expansion->setnodesval(&ABvalr);
		Expansion->computeFourierCplx_disc();
		pFCoeff=Expansion->getFourierCoefficients();
		Extension->setFourierCoeff(pFCoeff);
		polar[0]=rr;  polar[1]=thetar;
		scatteringfield=scatteringfield+Extension->evalScatteringField(polar);
		//scatteringfield =1.0;
	//}
	
	return scatteringfield;
}

void IterativeSolverMulScatProblem::outputPlot(const char *filename, INT refine){
	 ofstream output(filename);
    output<<"TITLE = \"Example: Simple XY Plot\""<<endl;
    output<<"VARIABLES = \"X\", \"Y\", \"u\", \"v\""<<endl;

    INT i, j, k, N=refine;
    DOUBLE R1=1.0,R2=1.0;
    Vector center1=GetCenterCoord(0);
    Vector center2=GetCenterCoord(1);

    Matrix coord(2, (N+1)*(N+1));
    DOUBLE dx=6.0/N, dy=6.0/N;
    k=0;
    for (i=0; i<N+1; i++){
        for (j=0; j<N+1; j++){
            coord[0][k]=j*dx-2.0;
            coord[1][k]=i*dy-3.0;
            k++;
        }
    }
    int eledof=(N+1)*(N+1);
    Vector x(2), lambda(2);
    for (i=0; i<4; i++){
        output<<"ZONE T=\""<<i<<"\","<<"N="<<eledof<<","<<"E="<<N*N<<","<<"ET=quadrilateral, F=FEPOINT"<<endl;
        for (j=0; j<eledof; j++){
            lambda[0]=coord[0][j]; lambda[1]=coord[1][j];

            Complex val;
            if ((lambda-center1).norm()>R1 && (lambda-center2).norm()>R2)
                val=ComputeScatteringField(lambda);
            else
                val=0.0;
            output<<setprecision(15)<<setw(20)<<lambda[0]<<"\t";
            output<<setprecision(15)<<setw(20)<<lambda[1]<<"\t";
            output<<setprecision(15)<<setw(20)<<val.rp()<<"\t";
            output<<setprecision(15)<<setw(20)<<val.ip()<<endl;
//            output<<setprecision(15)<<setw(20)<<coef->c(x).rp()<<endl;
        }
        for (j=0; j<N; j++){
            for (k=0; k<N; k++){
                INT ic=j*(N+1)+k+1;
                output<<setw(10)<<ic<<"\t";
                output<<setw(10)<<ic+1<<"\t";
                output<<setw(10)<<ic+N+2<<"\t";
                output<<setw(10)<<ic+N+1<<endl;
            }
        }
    }
    return;
    output.close();
    return;
//	INT i, j, k, N=refine;
//    DOUBLE r, theta, pi=4.0*atan(1.0);
//    DOUBLE R1=0.0, R2=3.0;
//    ofstream output(filename);
//    output<<"TITLE = \"Example: Simple XY Plot\""<<endl;
//    output<<"VARIABLES = \"X\", \"Y\", \"u\""<<endl;
//
//    Vector kv(2);
//    kv(1)=10.0;  kv(2)=10.0;
//    IncidentWave *f=new IncidentWave(kv, 0.5);
//
//    Matrix coord(2, (N+1)*(N+1));
//    DOUBLE dx=2.0/N;
//    k=0;
//    for (i=0; i<N+1; i++){
//        for (j=0; j<N+1; j++){
//            coord[0][k]=j*dx-1.0;
//            coord[1][k]=i*dx-1.0;
//            k++;
//        }
//    }
//    int eledof=(N+1)*(N+1);
//    int nRow=N;
//    Vector x(2), lambda(2),mu(2);
//    for (i=0; i<4; i++){
//        output<<"ZONE T=\""<<i<<"\","<<"N="<<eledof<<","<<"E="<<nRow*nRow<<","<<"ET=quadrilateral, F=FEPOINT"<<endl;
//        for (j=0; j<eledof; j++){
//            lambda[0]=coord[0][j]; lambda[1]=coord[1][j];
//            r=(R2-R1)/2*lambda[1]+(R2+R1)/2;
//            theta=pi/4.0*lambda[0]+pi*(i+1)/2.0;
//            mu[0]=r;  mu[1]=theta;
//           
//            x[0]=r*cos(theta)+1.1;  x[1]=r*sin(theta);
//            //f->setRadius(r);
//            Complex inc=f->c(x);
//            output<<setprecision(15)<<setw(20)<<x[0]<<"\t";
//            output<<setprecision(15)<<setw(20)<<x[1]<<"\t";
//            output<<setprecision(15)<<setw(20)<<ComputeScatteringField(x).rp()<<endl;
//        }
//        for (j=0; j<nRow; j++){
//            for (k=0; k<nRow; k++){
//                INT ic=j*(nRow+1)+k+1;
//                output<<setw(10)<<ic<<"\t";
//                output<<setw(10)<<ic+1<<"\t";
//                output<<setw(10)<<ic+nRow+2<<"\t";
//                output<<setw(10)<<ic+nRow+1<<endl;
//            }
//        }
//    }
//    output.close();
//    return;
}

void IterativeSolverMulScatProblem::DrawPatch(ofstream &output, int solverindex, INT refine){
    INT i, j, k;
    SpectralElementSpace *space=(SpectralElementSpace *)LocalSolver[solverindex]->getFEMSpace(0);
    Grid * grid=space->getGrid2D();
    Matrix coord(2, (refine+1)*(refine+1));
    DOUBLE dx=2.0/refine, dy=2.0/refine;
    k=0;
    for (i=0; i<refine+1; i++){
        for (j=0; j<refine+1; j++){
            coord[0][k]=j*dx-1.0;
            coord[1][k]=i*dy-1.0;
            k++;
        }
    }
    DOUBLE *x1, *x2, *x3, *x4;
    Vector xt(2), lambda(2);
    int eledof=(refine+1)*(refine+1);
    for (i=0; i<grid->getNElement(); i++){
        x1=grid->getElement(i)->getVertex(0)->getCoord();
        x2=grid->getElement(i)->getVertex(1)->getCoord();
        x3=grid->getElement(i)->getVertex(2)->getCoord();
        x4=grid->getElement(i)->getVertex(3)->getCoord();
        output<<"ZONE T=\""<<i+solverindex*grid->getNElement()<<"\","<<"N="<<eledof<<","<<"E="<<refine*refine<<","<<"ET=quadrilateral, F=FEPOINT"<<endl;
        for (j=0; j<eledof; j++){
            lambda[0]=coord[0][j]; lambda[1]=coord[1][j];
            // for ( k=0; k<2; k++ )
                // xt[k] = (x1[k]+x2[k]+x3[k]+x4[k]
                   // + (x2[k]+x3[k]-x1[k]-x4[k])*lambda[0]
                   // + (x3[k]+x4[k]-x1[k]-x2[k])*lambda[1]
                   // + (x1[k]+x3[k]-x2[k]-x4[k])*lambda[0]*lambda[1])/4.0;
            Vector *res, *ims, vr, vi,centercoord(2),polarcoord(2);
            res=LocalSolver[solverindex]->getSolution(0);
            ims=LocalSolver[solverindex]->getSolution(1);
			
            // lambda=space->inverseMapping(i, xt);
            space->interpolant(i, lambda, *res, vr);
            space->interpolant(i, lambda, *ims, vi);
			lambda=space->mapping(i, lambda);
            Complex c=0.0;
            for (k=0; k<nScatterers; k++){
                if (k==solverindex) continue;
                PVector valk=LocalSolver[k]->getArtificialBoundaryValue();
                centercoord=GetCenterCoord(k);
                cartTopolar(lambda[0]-centercoord[0],lambda[1]-centercoord[1],polarcoord[0],polarcoord[1]);
                Expansion->setnodesval(valk);
                Expansion->computeFourierCplx_disc();
                Complex* FCoeef=Expansion->getFourierCoefficients();
                Extension->setFourierCoeff(FCoeef);

                c=c+ Extension->evalScatteringField(polarcoord);
            }   

            output<<setprecision(15)<<setw(20)<<lambda[0]<<"\t";
            output<<setprecision(15)<<setw(20)<<lambda[1]<<"\t";
            output<<setprecision(15)<<setw(20)<<vr[0]+c.rp()<<"\t";
            output<<setprecision(15)<<setw(20)<<vi[0]+c.ip()<<"\t";
			output<<setprecision(15)<<setw(20)<<vr[0]+c.rp()-coefficient_ptr[1]->d(lambda)<<"\t";
			output<<setprecision(15)<<setw(20)<<vi[0]+c.ip()-coefficient_ptr[2]->d(lambda)<<endl;
        }
        for (j=0; j<refine; j++){
            for (k=0; k<refine; k++){
                INT ic=j*(refine+1)+k+1;
                output<<setw(10)<<ic<<"\t";
                output<<setw(10)<<ic+1<<"\t";
                output<<setw(10)<<ic+refine+2<<"\t";
                output<<setw(10)<<ic+refine+1<<endl;
            }
        }
    }
    return;
}

void IterativeSolverMulScatProblem::outputTecPlotDataFile(const char *filename){
    ofstream output(filename);
    output<<"TITLE = \"Example: Simple XY Plot\""<<endl;
    output<<"VARIABLES = \"X\", \"Y\", \"u\", \"v\", \"totolre\", \"totolim\""<<endl;
    for (int i=0; i<nScatterers; i++){
        DrawPatch(output, i, 30);
    }
    output.close();
    return;
}



// void IterativeSolverMulScatProblem::\
//                           Multiorthognal_Arnodi_Decomposition(INT k,Matrix &Vk, Matrix &H, Matrix &h, Matrix &RF){
//     Matrix Uh,tem,v,Hk,Tk;
// 	Vk.setDim(2*NBP,k+1); Vk=0.0;
// 	Tk.setDim(2*NBP,k  ); Tk=0.0;
// 	Uh.setDim(2*NBP,  1); Uh=0.0;
// 	Vector Vtem;
// 	Vector r0; r0.setDim(2*NBP);
// 	r0=0.0;
// 	h.setDim(k+1,k);
// 	Hk.setDim(k,k); Hk=0.0;

// 	Vector BoundaryRHS;
// //	BoundaryRHS.setDim(2*NBP);
// //	for(INT i=0;i<nScatterers;i++){
// //		LocalSolver[i]->getBoundaryRHS();
// //		for(INT j=0;j<2*NP[i];j++){
// //			BoundaryRHS[j+i*2*NP[i]]=(LocalSolver[i]->getRV())[j];
// //		}
// //	}

// 	getGeneralBoundaryRHS(BoundaryRHS);
// 	DOUBLE beta=BoundaryRHS.norm();
// 	RF.setDim(k+1,1); RF=0.0;
// 	RF[0][0]=beta;//Get the right hand side of equation after Arnoldi procedure!-)

// 	Vector BoundaryVal;
// 	BoundaryVal.setDim(2*NBP);
// 	getGeneralBoundaryRHS(BoundaryVal);//Setteing an initial point which may be arbiturary but must be
// 									   //initialized for Arnoldi decomposition!-)
// 	DOUBLE nor=BoundaryVal.norm();
// 	BoundaryVal=BoundaryVal*(1.0/nor);//as an initial point!-)
// 	for(INT i=0;i<2*NBP;i++){
// 		Vk[i][0]=BoundaryVal[i];
// 	}
// 	h=0.0;
// 	for(INT j=0; j<k; j++){
// 		//cout<<BoundaryVal<<endl;
//         BoundaryVal=GloblfreematrixProdvector(BoundaryVal);//Get Tv_j !-)
//         for(INT i=0;i<2*NBP;i++){
//         	Tk[i][j]=BoundaryVal[i];
//         	Uh[i][0]=BoundaryVal[i];
// 		}

// 		tem=Uh;
// 		for(INT i=0; i<=j; i++){
// 			Matrix vi=Vk.getSubMatrix(0,i,2*NBP-1,i);
// 			h[i][j]=(Uh.transpose()*vi)[0][0];
// 			tem=tem-vi*h[i][j];
// 		}

// 		for(INT i=0; i<=j; i++){
// 			Matrix vi=Vk.getSubMatrix(0,i,2*NBP-1,i);
// 			DOUBLE s=(vi.transpose()*tem)[0][0];
// 			h[i][j]+=s;
// 			tem=tem-vi*s;
// 		}
// 		Vtem=matrixToVector(tem);
// 		h[j+1][j]=Vtem.norm();
// 		v=tem*(1.0/h[j+1][j]);
// 		for(INT n=0;n<2*NBP;n++)
// 			BoundaryVal[n]=v[n][0];
// 		for(INT i=0;i<2*NBP;i++)
// 			Vk[i][j+1]=v[i][0];
// 	}
// 	Matrix V=Vk.getSubMatrix(0,0,2*NBP-1,k-1);
// 	H.setDim(k+1,k);
// 	H=0.0;
// 	Hk=V.transpose()*Tk;
// 	for(INT i=0;i<k;i++){
// 		for(INT j=0; j<k;j++){
// 			H[i][j]=Hk[i][j];
// 		}
// 	}
// 	H[k][k-1]=h[k][k-1];
// 	cout<<"The difference is: "<<(Vk*H-Tk).maxNorm()<<endl;// As what we have expected, Hk, kxk,
// 														   //is a uppper Hessenberg matrix !-)
// 	//cout<<Vk.transpose()*Vk<<endl;
// //	cout<<"***************"<<endl;
// //	cout<<"Hk"<<endl;
// //	cout<<Hk<<endl;
// //	cout<<H<<endl;
// //	cout<<"***************"<<endl;
// //	cout<<"Vk"<<endl;
// //	cout<<Vk<<endl;
// //	Matrix subVk=Vk.getSubMatrix(0,0,2*NboundaryNodes-1,k-1);
// //	cout<<(subVk*Hk-Tk).maxNorm()<<endl;
// //	cout<<"***************"<<endl;
// //	cout<<"h"<<endl;
// //	cout<<h<<endl;
// }

// /******************************
// The following three functions are independent of LocalSolver!-)
// ******************************/
// void IterativeSolverMulScatProblem::Produce_Givens(DOUBLE a, DOUBLE b, DOUBLE &c, DOUBLE &s){
//      DOUBLE tau;
//      if (b==0.0){
//         c=1.0; s=0.0;
//      }
//      else{
//          if (fabs(b)>fabs(a)){
//              tau=a/b;
//              s=1.0/sqrt(1.0+tau*tau);
//              c=s*tau;
//          }
//          else{
//              tau= b/a;
//              c=1.0/sqrt(1.0+tau*tau);
//              s=c*tau;
//          }
//      }
// }

// void IterativeSolverMulScatProblem::QR_Decomposition(Matrix A, Matrix RF, Matrix &Q, Matrix &R,Matrix &RFk){
// 	DOUBLE c,s;
// 	Matrix QK;
// 	INT nofrow=A.getN();
// 	INT nofcol=A.getM();
// 	QK=eye(nofrow);
// 	for(INT j=0; j<nofcol; j++){
// 		for(INT i=0;i<nofrow-j-1;i++){
// 		    Q=eye(nofrow);
// 			Produce_Givens(A[j][j],A[nofrow-i-1][j],c,s);
// 			Q[j         ][j]= c; Q[j         ][nofrow-i-1]=s;
// 			Q[nofrow-i-1][j]=-s; Q[nofrow-i-1][nofrow-i-1]=c;
// 			A=Q*A; //Givens Transformation!-)
// 			QK=Q*QK;
// 		}
// 	}
// 	RFk=QK*RF;
// 	R=A;
// 	Q=QK;
// }

// /*********************************
// To fix our idea, we consider the matrix A
// which is of dimension (k+1)xk, and the matrix
// (or, column vector) g, which is of dimension
// (k+1)x1. Note that the submatrix subA is a upper
// trangular matrix!-)
// *********************************/
// void IterativeSolverMulScatProblem::Least_Square_Sol(Matrix A, Matrix g, Matrix &Sol){
// 	Vector usol;
// 	INT nofrow=A.getN();
// 	INT nofcol=A.getM();
// 	INT numele=g.getN();
// 	Sol.setDim(nofrow-1,1);
// 	Matrix subA=A.getSubMatrix(0,0,nofrow-2,nofcol-1);// subA is a upper triangular square matrix!-)
// 	Matrix subg=g.getSubMatrix(0,0,numele-2,0);
// 	Vector newg=matrixToVector(subg);
// 	usol=subA.solveUpperTriangle(newg);               // Solving the upper triangular system
// 	INT num=newg.getDim();
// 	for(INT i=0;i<num;i++)
// 	    Sol[i][0]=usol[i];
// }
//


///***********************************
//Now, we are in a position to implicate GMRES method,
//we shall take 0 as an initial point for insistence,
//and we choose the residure as an initial point in
//Arnoldi decomposition. Note that we use the relative
//error !-)
//***********************************/
// void IterativeSolverMulScatProblem::GMRES_Iteration(Vector &BoundaryVal){
//     Matrix Hk,H,g,h,RFQ,Q,R,RF,RFk,Sol;
//     NBP=0;
//     Vector TEM;
//     for(INT i=0; i<nScatterers;i++){   //Obtain the sum of all points on boundaries of the whole scatterers!-)
//     	LocalSolver[i]->getBoundaryInf();
//     	NP[i]=LocalSolver[i]->getNB();
//     	NBP+=NP[i];
// 	}
// 	cout<<NBP<<endl;
// 	Vector GeneralBoundaryRHS;
// 	getGeneralBoundaryRHS(GeneralBoundaryRHS);
// 	DOUBLE row=GeneralBoundaryRHS.norm();
// 	Vector newBoundaryVal(2*NBP);
// 	INT k=2;
// 	DOUBLE EPS=1e-12;
//     while(row/GeneralBoundaryRHS.norm()>EPS){
//          Multiorthognal_Arnodi_Decomposition(k, Hk, H, h, RF);
//          cout<<"Multiorthogonal Arnoldi decomposition has completed! "<<endl;
//          QR_Decomposition(H, RF, Q, R, RFk);
//          cout<<"QR decomposition has completed! "<<endl;
//          g.setDim(R.getN(),1);
//          g=0.0;
//          for(INT i=0;i<R.getN()-1;i++)
//              g[i][0]=RFk[i][0];
//          Least_Square_Sol(R, g, Sol);
//          cout<<"Least square has completed! "<<endl;
//          Matrix Vk=Hk.getSubMatrix(0,0,2*NBP-1,k-1);
// 		 BoundaryVal.setDim(2*NBP);
//          Matrix SOL=Vk*Sol;
//          for(INT j=0;j<2*NBP;j++)
//              BoundaryVal[j]=SOL[j][0];

// 		 //cout<<BoundaryVal<<endl;

//          TEM=GloblfreematrixProdvector(BoundaryVal);
//          //cout<<BoundaryVal<<endl;
//          row=(GeneralBoundaryRHS-TEM).norm();
//          cout<<"The error is:  "<<row<<endl;
//          ++k;
//     }
// }


//

