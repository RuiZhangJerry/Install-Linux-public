#include "SpectralElementSpace.h"

Vector InnerBdryParameterForm:: v(Vector x){
    Vector a1(2);
    DOUBLE rr=0.5*(0.7+0.2*sin(5.0*x[0]));
    a1[0]=rr*cos(x[0]);
    a1[1]=rr*sin(x[0]);

    return a1;
}

Vector OuterBdryParameterForm:: v(Vector x){
    Vector a2(2);
    a2[0]=x[0]*cos(x[1]);
    a2[1]=x[0]*sin(x[1]);

    return a2;
}

Vector DiffInnerBdryParameterForm:: v(Vector x){
    Vector da1(2);
    da1[0]=0.5*(-0.7*sin(x[0])*((x[1]-x[2])/2.0)+0.2*(5.0*cos(5.0*x[0])*((x[1]-x[2])/2.0)*cos(x[0])-sin(5.0*x[0])*sin(x[0])*((x[1]-x[2])/2.0)));
    da1[1]=0.5*( 0.7*cos(x[0])*((x[1]-x[2])/2.0)+0.2*(5.0*cos(5.0*x[0])*((x[1]-x[2])/2.0)*sin(x[0])+sin(5.0*x[0])*cos(x[0])*((x[1]-x[2])/2.0)));

    return da1;
}

Vector DiffOuterBdryParameterForm:: v(Vector x){
    Vector da2(2);
    da2[0]=-x[0]*sin(x[1])*((x[2]-x[3])/2.0);
    da2[1]= x[0]*cos(x[1])*((x[2]-x[3])/2.0);

    return da2;
}






Vector SpectralElementSpace::mapping(INT i, Vector &lambda){
    Vector v1(2), v2(2), v3(2), v4(2);
    Vector v(2);
    DOUBLE x[2], r, tmp;
    Element *e=femg->getElement(i);
    v1=e->getVertex(0)->getCoord();
    v2=e->getVertex(1)->getCoord();
    v3=e->getVertex(2)->getCoord();
    v4=e->getVertex(3)->getCoord();

        DOUBLE pi=4.0*atan(1.0);
        DOUBLE r1, r2, r3, r4, theta1, theta2, theta3, theta4, theta;
        cartTopolar(v1[0]-MoveVector[0], v1[1]-MoveVector[1], r1, theta1);
        cartTopolar(v2[0]-MoveVector[0], v2[1]-MoveVector[1], r2, theta2);
        cartTopolar(v3[0]-MoveVector[0], v3[1]-MoveVector[1], r3, theta3);
        cartTopolar(v4[0]-MoveVector[0], v4[1]-MoveVector[1], r4, theta4);
         if(theta2<theta1)
            theta2+=2.0*pi;
		 if (theta3<theta4)
            theta3+=2.0*pi;
        Vector a1(2), a2(2), a3(2), a4(2);
		
		// theta=(theta3-theta4)/2.0*lambda[0]+(theta4+theta3)/2.0;//pi_1
		// DOUBLE rr=0.5*(0.7+0.2*sin(5.0*theta));
		// a1[0]=rr*cos(theta)+MoveVector[0];
		// a1[1]=rr*sin(theta)+MoveVector[1];

        theta=(theta2-theta1)/2.0*lambda[0]+(theta2+theta1)/2.0;//pi_1
        Vector xx(2); xx[0]=theta;
        a1=Coefficient_ptr[0]->v(xx);
        a1+=MoveVector;

        a2[0]=(v3[0]-v2[0])/2.0*lambda[1]+(v3[0]+v2[0])/2.0;
        a2[1]=(v3[1]-v2[1])/2.0*lambda[1]+(v3[1]+v2[1])/2.0;//pi_2

        //DOUBLE b0=sqrt((v3[0]-MoveVector[0])*(v3[0]-MoveVector[0])+(v3[1]-MoveVector[1])*(v3[1]-MoveVector[1]));
        theta=(theta3-theta4)/2.0*lambda[0]+(theta3+theta4)/2.0;
        // a3[0]=r3*cos(theta)+MoveVector[0];
        // a3[1]=r3*sin(theta)+MoveVector[1];// pi_3
        xx[0]=r3;  xx[1]=theta;
        a3=Coefficient_ptr[1]->v(xx);
        a3+=MoveVector;

        a4[0]=(v4[0]-v1[0])/2.0*lambda[1]+(v4[0]+v1[0])/2.0;
        a4[1]=(v4[1]-v1[1])/2.0*lambda[1]+(v4[1]+v1[1])/2.0;//pi_4


        a4=(v4-v1)*(lambda[1]/2.0)+(v4+v1)/2.0;//pi_4

        v=(1-lambda[1])/2.0*a1+(1+lambda[1])/2.0*a3+(1+lambda[0])/2.0*a2+(1-lambda[0])/2.0*a4;
        v=v-(v1*(1-lambda[0])/2.0+v2*(1+lambda[0])/2.0)*(1-lambda[1])/2.0;
        v=v-(v4*(1-lambda[0])/2.0+v3*(1+lambda[0])/2.0)*(1+lambda[1])/2.0;

//    }
    return v;

}

DOUBLE SpectralElementSpace::jacobi(INT i, Vector &lambda){
    Matrix mat=JM(i, lambda);
    return mat.det();
}

Matrix SpectralElementSpace::JM(INT i, Vector &lambda){
    Matrix mat(2, 2);
    DOUBLE gx[2][2], x[2], xt[2];
    DOUBLE *v1, *v2, *v3, *v4;
    Element *e=femg->getElement(i);
    v1=e->getVertex(0)->getCoord();
    v2=e->getVertex(1)->getCoord();
    v3=e->getVertex(2)->getCoord();
    v4=e->getVertex(3)->getCoord();

        DOUBLE pi=4.0*atan(1.0);
        DOUBLE r1, r2, r3, r4, theta1, theta2, theta3, theta4, theta;
        cartTopolar(v1[0]-MoveVector[0], v1[1]-MoveVector[1], r1, theta1);
        cartTopolar(v2[0]-MoveVector[0], v2[1]-MoveVector[1], r2, theta2);
        cartTopolar(v3[0]-MoveVector[0], v3[1]-MoveVector[1], r3, theta3);
        cartTopolar(v4[0]-MoveVector[0], v4[1]-MoveVector[1], r4, theta4);
         if(theta2<theta1)
            theta2+=2.0*pi;
         if (theta3<theta4)
            theta3+=2.0*pi;

        Vector a1(2), da1(2), a2(2), a3(2), da3(2), a4(2);
		
        theta=(theta2-theta1)/2.0*lambda[0]+(theta2+theta1)/2.0;
        Vector xx(2); xx[0]=theta;
        a1=Coefficient_ptr[0]->v(xx);
        a1+=MoveVector;

        Vector dx(4);
        dx[0]=theta;  dx[1]=theta2;  dx[2]=theta1;
        da1=Coefficient_ptr[2]->v(dx);

		// DOUBLE rr=0.5*(0.7+0.2*sin(5.0*theta));
		// a1[0]=rr*cos(theta)+MoveVector[0];
		// a1[1]=rr*sin(theta)+MoveVector[1];
		// da1[0]=0.5*(-0.7*sin(theta)*((theta3-theta4)/2.0)+0.2*(5.0*cos(5.0*theta)*((theta3-theta4)/2.0)*cos(theta)-sin(5.0*theta)*sin(theta)*((theta3-theta4)/2.0)));
		// da1[1]=0.5*( 0.7*cos(theta)*((theta3-theta4)/2.0)+0.2*(5.0*cos(5.0*theta)*((theta3-theta4)/2.0)*sin(theta)+sin(5.0*theta)*cos(theta)*((theta3-theta4)/2.0)));

        a2[0]=(v3[0]-v2[0])/2.0*lambda[1]+(v3[0]+v2[0])/2.0;
        a2[1]=(v3[1]-v2[1])/2.0*lambda[1]+(v3[1]+v2[1])/2.0;//pi_2

        //DOUBLE b0=sqrt((v3[0]-MoveVector[0])*(v3[0]-MoveVector[0])+(v3[1]-MoveVector[1])*(v3[1]-MoveVector[1]));
        
        theta=(theta3-theta4)/2.0*lambda[0]+(theta4+theta3)/2.0;
        xx[0]=r3;  xx[1]=theta;
        a3=Coefficient_ptr[1]->v(xx);
        a3+=MoveVector;

        dx[0]=r3; dx[1]=theta; dx[2]=theta3; dx[3]=theta4;
        da3=Coefficient_ptr[3]->v(dx);

        // a3[0]=r3*cos(theta)+MoveVector[0];
        // a3[1]=r3*sin(theta)+MoveVector[1];// pi_3

        // da3[0]=-r3*sin(theta);
        // da3[1]=r3*cos(theta);

        a4[0]=(v4[0]-v1[0])/2.0*lambda[1]+(v4[0]+v1[0])/2.0;
        a4[1]=(v4[1]-v1[1])/2.0*lambda[1]+(v4[1]+v1[1])/2.0;//pi_4


        // mat[0][0]=(1-lambda[1])/2.0*(v2[0]-v1[0])/2.0+(theta3-theta4)/2.0*(1+lambda[1])/2.0*da3[0]+(a2[0]-a4[0])/2.0;
        // mat[0][0]=mat[0][0]-(v2[0]-v1[0])*(1-lambda[1])/4.0;
        // mat[0][0]=mat[0][0]-(v3[0]-v4[0])*(1+lambda[1])/4.0;
		mat[0][0]=(1-lambda[1])/2.0*da1[0]+(1+lambda[1])/2.0*da3[0]+(a2[0]-a4[0])/2.0;
        mat[0][0]=mat[0][0]-(v2[0]-v1[0])*(1-lambda[1])/4.0;
        mat[0][0]=mat[0][0]-(v3[0]-v4[0])*(1+lambda[1])/4.0;
		
		mat[0][1]=(1-lambda[1])/2.0*da1[1]+(1+lambda[1])/2.0*da3[1]+(a2[1]-a4[1])/2.0;
        mat[0][1]=mat[0][1]-(v2[1]-v1[1])*(1-lambda[1])/4.0;
        mat[0][1]=mat[0][1]-(v3[1]-v4[1])*(1+lambda[1])/4.0;


        // mat[0][1]=(1-lambda[1])/2.0*(v2[1]-v1[1])/2.0+(theta3-theta4)/2.0*(1+lambda[1])/2.0*da3[1]+(a2[1]-a4[1])/2.0;
        // mat[0][1]=mat[0][1]-(v2[1]-v1[1])*(1-lambda[1])/4.0;
        // mat[0][1]=mat[0][1]-(v3[1]-v4[1])*(1+lambda[1])/4.0;


        mat[1][0]=-1.0/2.0*a1[0]+1.0/2.0*a3[0]+(1+lambda[0])/2.0*(v3[0]-v2[0])/2.0+(1-lambda[0])/2.0*(v4[0]-v1[0])/2.0;
        mat[1][0]=mat[1][0]+(v1[0]-v4[0])*(1-lambda[0])/4.0;
        mat[1][0]=mat[1][0]+(v2[0]-v3[0])*(1+lambda[0])/4.0;


        mat[1][1]=-1.0/2.0*a1[1]+1.0/2.0*a3[1]+(1+lambda[0])/2.0*(v3[1]-v2[1])/2.0+(1-lambda[0])/2.0*(v4[1]-v1[1])/2.0;
        mat[1][1]=mat[1][1]+(v1[1]-v4[1])*(1-lambda[0])/4.0;
        mat[1][1]=mat[1][1]+(v2[1]-v3[1])*(1+lambda[0])/4.0;
//    }
    return mat;

}

Matrix SpectralElementSpace::JMIT(INT i, Vector &lambda){
    Matrix mat=JM(i, lambda);
    return mat.inverse();
}


/*********************************
In order to get inverse Gordon-Hall mapping, we use
the Newton Iterated Method to solve the nonlinear
equations F_e(\xi,\eta)-x=0 , where \xi,\eta \in [-1,1],
so we may take the x0=(0,0)' as an initial point !-)
*********************************/
Vector SpectralElementSpace::inverseMapping(INT i, Vector &x){
       //x=x-MoveVector;
       Matrix Init;
       Init.setDim(2,1);
       Init=0.0;
       Matrix X(2,1);
       Vector vInit=matrixToVector(Init);
       DOUBLE error=(x-mapping(i, vInit)).norm();

       while(error>1.0e-15){
       	   Vector tem=mapping(i,vInit)-x;
       	   X[0][0]=tem[0]; X[1][0]=tem[1];
           Init-=JMIT(i,vInit).transpose()*X; //Be Caution, the Jacobean function F'(x_k) is Transpose of JMIT!!!
           vInit=matrixToVector(Init);
           error=(x-mapping(i, vInit)).norm();
       }

       return vInit;
}
//DOUBLE SpectralElementSpace::L2Error(Coefficient *f, Vector &uh){
//    Quadrature *quad=new Quadrature(RECTANGLE, GAUSS_QUADRATURE);
//    quad->permuteData(12);
//    Matrix   gaussPoint=quad->getPoints();
//    DOUBLE * gaussWeight=quad->getWeights();
//    int n=quad->getNPoints();

//    int nd=((LAGRANGE_2D_SQUARE*)trial[0])->getPolynomialDegree();
//    DOUBLE L2norm2=0.0;
//    Vector lambda(2), x;

//    if (dimension==2){
//        for (INT k=0; k<femg->getNElement(); k++){
//            DOUBLE sum=0.0;
//            for (INT iq=0; iq<n; iq++){
//                Vector val;
//                lambda[0]=gaussPoint[0][iq];	lambda[1]=gaussPoint[1][iq];
//                interpolant(k, lambda, uh, val);
//                x=mapping(k, lambda);
//                DOUBLE tmp=f->d(x);
//                DOUBLE ja=jacobi(k, lambda);
//                sum=sum+(tmp-val[0])*(tmp-val[0])*gaussWeight[iq]*fabs(ja);
//			//	cout<<"jacobi"<<ja<<endl;
//            }

//            L2norm2+=sum;
//        }
//    }
//    delete quad;
//    return sqrt(L2norm2);
//}

//DOUBLE SpectralElementSpace::L2ErrorOfGrad(Coefficient *f, Vector &uh){
//    Quadrature *quad;
//    if (dimension==2)
//        quad=new Quadrature(RECTANGLE, GAUSS_QUADRATURE);
//    else{
//        if (dimension==3){
//            quad=new Quadrature(CUBE, GAUSS_QUADRATURE);
//        }
//        else
//            quad=new Quadrature(INTERVAL, GAUSS_QUADRATURE);
//    }


//    quad->permuteData(trial[0]->getPolynomialDegree()+1);
//    Matrix   gaussPoint=quad->getPoints();
//    DOUBLE * gaussWeight=quad->getWeights();
//    int n=quad->getNPoints();
//    DOUBLE L2norm2=0.0;
//    Vector lambda(2), x;

//    for (INT k=0; k<femg->getNElement(); k++){
//        DOUBLE sum=0.0;
//        for (INT iq=0; iq<n; iq++){
//            Vector val;
//            lambda[0]=gaussPoint[0][iq];	lambda[1]=gaussPoint[1][iq];
//            interpolantGradient(k, lambda, uh, val);
//            x=mapping(k, lambda);
//            Vector tmp=f->v(x);
//            DOUBLE ja=jacobi(k, lambda);
//            sum=sum+((tmp[0]-val[0])*(tmp[0]-val[0])+(tmp[0]-val[0])*(tmp[0]-val[0]))*gaussWeight[iq]*ja;
//        }

//        L2norm2+=sum;
//    }

//    delete quad;
//    return sqrt(L2norm2);
//}

