#include <iostream>
#include "Iterative_Solver_Multiple_Scattering_Problem.h"

using namespace std;

#define MARK cout<<"hello!\n";

int main(){

    int polydeg[2];
	for(int i=0;i<2;i++){
		polydeg[i]=11;
	}cout<<"$$"<<endl;
    IterativeSolverMulScatProblem *problem=new IterativeSolverMulScatProblem(2,  polydeg);  //°ÑÒ»¸öÉ¢ÉäÎÊÌâÇó½âÆ÷·Å½øÈ¥


    problem->solve();
    cout<<"debug"<<endl;
    return 0;

    //problem->outputTecPlotDataFile("scatteringwave.dat");
   // problem->outputPlot("fullplot.dat", 500);
//    problem->getBoundaryVal();
//    Vector BV=problem->getBV();
//    cout<<BV<<endl;
//    problem->ITERATE_solve();
//    problem->getBoundaryVal();
    //problem->GMRESm_Iteration();
    //problem->GMRES_Iteration();
    //problem->Multiorthognal_Arnodi_Decomposition(2,Vk,H,h,RF);

}
