#include "SE_var_coefficient_HELMHOLTZ_Eq_def.h"
#include <gsl/gsl_sf_bessel.h>
//#include <gsl/gsl_sf.h>

#include <math.h>
DOUBLE ScalarCoefficient::d(Vector x){
    return 1.0;
}

Complex tc(Vector x){
	Complex u;
	u.rp()=cos(x[0]); u.ip()=sin(x[0]);
	return u;
}

//Construct the EQ.
//********************************************************
//
//                     solution u=exp(ikx)
//
//********************************************************
DOUBLE ReExactSolution ::d(Vector x){
    return cos(kn*x[0]);
    //return 0.0;
}
DOUBLE ImExactSolution ::d(Vector x){
    return sin(kn*x[0]);
    //return 0.0;
}
//********************************
//The boundary condition of scatter \Omega_0, u_i = exp(ikx), on \partial {\Omega_0}
DOUBLE ReBoundaryCondition::d(Vector x){
    return cos(kn*x[0]);

}
DOUBLE ImBoundaryCondition::d(Vector x){
    return sin(kn*x[0]);
}
//***************************************
//The right hand side of the HELMHOLTZ eq. is zero.
DOUBLE ReRHSFunc:: d(Vector x){
    return 0.0;
}
DOUBLE ImRHSFunc:: d(Vector x){
    return 0.0;
}
//***************************************
//There are two kinds of ABC, one is First order BC, another is NRBC condition, we use the NRBC.
DOUBLE ReFirstorderg:: d(Vector x){
    return 0.0;
}
DOUBLE ImFirstorderg:: d(Vector x){

    return 0.0;
}

DOUBLE ReNRBCg:: d(Vector x){
 
    return 0.0;
    
}

DOUBLE ImNRBCg:: d(Vector x){

    return 0.0;
   
}



//////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////



// *****************************************************************
//   compute v_{in} such that:
//       l_i(\xi)=\sum\limits_{n=0}^Nv_{in}P_n(\xi)  N=polyDeg
//   V=[v_{i0}, v_{i1}, \cdots, v_{iN}]
//
// *****************************************************************

Vector SE_VariableCoefficientHELMHLOTZProblem::LagrangeLobattoToLegendre(INT deg, INT index){
    Quadrature *quad=new Quadrature(INTERVAL, GAUSS_LOBATTAO_QUADRATURE);
    quad->permuteData(deg+1);

    Matrix qp =quad->getPoints();
    DOUBLE *wts=quad->getWeights();
    INT np=quad->getNPoints();

    Vector V(deg+1);
    V=0.0;

    for (int i=0; i<deg+1; i++){
        DOUBLE tmp=0.0;
        for(INT kk=0; kk<np; kk++){
            DOUBLE lambda=qp[0][kk];
            DOUBLE Legr1=gsl_sf_legendre_Pl(i, lambda);
            tmp+=Legr1*Legr1*wts[kk];
        }
        V[i]=gsl_sf_legendre_Pl(i, qp[0][index])*wts[index]/tmp;
    }
    delete quad;
    return V;
}

// *****************************************************************
//   compute Interpolation coefficents to Fourier coefficient transform
//   matrix K=(k_nj), where
//     k_{nj}=int_{\theta_1}^{\theta_2}l_j(\xi)e^{-in\theta}d\theta
//   Noting that a factor 1/(2\pi) is missing for fourier transform
// *****************************************************************
CMatrix SE_VariableCoefficientHELMHLOTZProblem::computeIntCoefToFCoef(DOUBLE theta_1, DOUBLE theta_2){
    DOUBLE pi=4.0*atan(1.0);
    LAGRANGE_2D_SQUARE * psf=(LAGRANGE_2D_SQUARE*)femspace[0]->getTestFunction(0);
    int polyDeg=psf->getPolynomialDegree();
    CMatrix IntCoefToFCoef(2*nFourierMode+1, polyDeg+1);
    if (theta_1>theta_2) theta_2=theta_2+2.0*pi;
    for (INT j=0; j<polyDeg+1; j++){
        Vector vj=LagrangeLobattoToLegendre(polyDeg, j);
        DOUBLE J=(theta_2-theta_1)/2.0;

        IntCoefToFCoef[nFourierMode][j]=2.0*vj[0]*J;
        for (INT k=1; k<=nFourierMode; k++){
            DOUBLE alpha=(theta_2+theta_1)/2.0;
            Complex ex;
            ex.rp()= cos(alpha*k);
            ex.ip()=-sin(alpha*k);
            Complex tmp=0.0;
            for(INT n=0; n<polyDeg+1; n++){
                DOUBLE jn=gsl_sf_bessel_jl(n, J*k);
                Complex ni;
                ni.rp()=cos(pi*n/2.0);
                ni.ip()=sin(pi*n/2.0);
                tmp=tmp+vj[n]*jn/ni;
            }
            IntCoefToFCoef[nFourierMode+k][j]=2.0*J*ex*tmp;
        }
        for (INT k=1; k<=nFourierMode; k++)
            IntCoefToFCoef[nFourierMode-k][j]=IntCoefToFCoef[nFourierMode+k][j].conjugate();
    }

    return IntCoefToFCoef;
}


void SE_VariableCoefficientHELMHLOTZProblem::computeRHS(){
    INT i, j,  k;
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid *grid=femspace[0]->getGrid2D();
    INT nc=grid->getNElement();
    LAGRANGE_2D_SQUARE * psf=(LAGRANGE_2D_SQUARE*)femspace[0]->getTestFunction(0);
    INT eledof=psf->degreeOfFreedom();
    Vector lambda(2), x(2);
    INT du=psf->degreeOfFreedom();
    INT Dof=femspace[0]->degreeOfFreedom();

    RHS[0]=new Vector(2*space->degreeOfFreedom());
    (*RHS[0])=0.0;

    INT np=quadrature->getNPoints();
    Matrix   qp=quadrature->getPoints();
    DOUBLE  *wts=quadrature->getWeights();
    INT nodeindex[du];
    psf->freedomToQuadrature(nodeindex);

    for (i=0; i<nc; i++){
        INT INDEX[eledof];
        femspace[0]->getGlobalIndex(i, INDEX);
        Vector tmp(eledof), tmp1(eledof);

        for (INT ii=0; ii<eledof; ii++){
            lambda[0]=qp[0][nodeindex[ii]];
            lambda[1]=qp[1][nodeindex[ii]];
            x=space->mapping(i, lambda);
            DOUBLE ja=space->jacobi(i, lambda);
            tmp[ii] =coefficient_ptr[3]->d(x)*fabs(ja)*wts[nodeindex[ii]];//Gauss integral
            tmp1[ii]=coefficient_ptr[4]->d(x)*fabs(ja)*wts[nodeindex[ii]];
        }
        for (INT ii=0; ii<eledof; ii++){
            (*RHS[0])[INDEX[ii]]+=tmp[ii];//Real part
            (*RHS[0])[INDEX[ii]+Dof]+=tmp1[ii];//Image part
        }
    }
}



void SE_VariableCoefficientHELMHLOTZProblem::computeLocalMatrices(INT index){
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    LAGRANGE_2D_SQUARE *pTrial=(LAGRANGE_2D_SQUARE*)femspace[0]->getTrialFunction(index);//强制转换变量类别
    INT j, k, ii, jj;

    INT eledof=pTrial->degreeOfFreedom();

    if (MLM[0]==NULL){
        MLM[0]=new Matrix(eledof, eledof);
        MLM[1]=new Matrix(eledof, eledof);
    }

    INT nEdgeNode=pTrial->getNEdgeNode();
    INT de=nEdgeNode+2;
    Vector lambda(2), x(2);
    INT np=quadrature->getNPoints();
    Matrix   qp=quadrature->getPoints();
    DOUBLE  *wts=quadrature->getWeights();
    Matrix mathbbK;
    mathbbK.setDim(eledof,eledof);
    mathbbK=0.0;

    INT nodeindex[eledof];
    pTrial->freedomToQuadrature(nodeindex);
    Quadrature *edgequad=new Quadrature(INTERVAL, quadrature->getType());
    edgequad->permuteData(de);
    for (ii=0; ii<eledof; ii++){
        lambda[0]=qp[0][nodeindex[ii]];
        lambda[1]=qp[1][nodeindex[ii]];
        DOUBLE ja=space->jacobi(index, lambda);
        (*MLM[1])[ii][ii]=fabs(ja)*wts[nodeindex[ii]];
    }

    for (j=0; j<np; j++){
        lambda[0]=qp[0][j];
        lambda[1]=qp[1][j];
        x=space->mapping(index, lambda);
        PMatrix pvalm, pvalmm;
        pvalm=pTrial->getBuffer(np+j);
        pvalmm=pTrial->getBuffer(j);

        DOUBLE cm=coefficient_ptr[0]->d(x);
        Matrix jmit=space->JMIT(index, lambda);
        Matrix valm=jmit*(*pvalm);
        Matrix tmpm=cm*valm;
        DOUBLE ja=space->jacobi(index, lambda);
        for (ii=0; ii<eledof; ii++)
            for (jj=0; jj<eledof; jj++)
                mathbbK [ii][jj]+=(valm[0][ii]*tmpm[0][jj]+valm[1][ii]*tmpm[1][jj])*fabs(ja)*wts[j];
    }


    for (ii=0; ii<eledof; ii++){
        for (jj=0; jj<eledof; jj++){
            (*MLM[0])[ii][jj]=mathbbK[ii][jj];
        }
    }
}
void SE_VariableCoefficientHELMHLOTZProblem::assemble(){
    Grid *grid=femspace[0]->getGrid2D();
    INT nc=grid->getNElement();
    INT i, j, k;
    PShapeFunction psf=femspace[0]->getTestFunction(0);
    INT np=quadrature->getNPoints();
    Matrix   qp=quadrature->getPoints();
    DOUBLE  *wts=quadrature->getWeights();
    psf->setNBuffer(2*np);
    Vector lambda(2);
    for (j=0; j<np; j++){
        lambda[0]=qp[0][j];
        lambda[1]=qp[1][j];
        PMatrix val=new Matrix();
        PMatrix gradval=new Matrix();
        psf->phi(lambda, *val);
        psf->grad_phi(lambda, *gradval);
        psf->setBuffer(j, val);
        psf->setBuffer(np+j, gradval);
    }
    INT Dof=femspace[0]->degreeOfFreedom();

    setNSMGM(1);	setNMLM(2);
    SMGM[0]=new Sparse(2*Dof, 2*Dof);  // stiff matrix
    for (i=0; i<nc; i++){
        INT eledof=psf->degreeOfFreedom();
        INT INDEX[eledof];
        femspace[0]->getGlobalIndex(i, INDEX);
        computeLocalMatrices(i);
        for (j=0; j<eledof; j++){
            for (k=0; k<eledof; k++){
                (*SMGM[0])(INDEX[j]+1, INDEX[k]+1)=(*SMGM[0])(INDEX[j]+1, INDEX[k]+1)-(*MLM[0])[j][k]+kn*kn*(*MLM[1])[j][k];
                (*SMGM[0])(INDEX[j]+1+Dof, INDEX[k]+1+Dof)=(*SMGM[0])(INDEX[j]+1+Dof, INDEX[k]+1+Dof)-(*MLM[0])[j][k]+kn*kn*(*MLM[1])[j][k];
            }
        }
    }
}


void SE_VariableCoefficientHELMHLOTZProblem::imposeBoundaryCondition(int nb){//nb is note the number of boundary, inner(scatter boundary) or outer(AB)
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid *grid=femspace[0]->getGrid2D();
    INT i, j, k;
    Vector pp(2*femspace[0]->degreeOfFreedom());
    Vector lambda(2), x(2);
    INT dof=space->degreeOfFreedom();
    for (i=0; i<nb; i++){
        BoundaryPatch *bp=grid->getBoundaryPatch(i);
        for (j=0; j<bp->getNVertex(); j++){
            Vertex *vertex=bp->getVertex(j);
//            pp[vertex->getIndex()]=BoundaryVal[0];
//            pp[vertex->getIndex()+dof]=0.0;
            pp[vertex->getIndex()    ] =BoundaryVal[j];
            pp[vertex->getIndex()+dof] =BoundaryVal[j+NboundaryNodes];
        }
        for (j=0; j<bp->getNEdge(); j++){               // Nodes on edges
            Edge *edge=bp->getEdge(j);
            Element *e=edge->getNeighborElement(0);
            INT index[femspace[0]->degreeOfFreedom(e->getIndex())];
            femspace[0]->getGlobalIndex(e->getIndex(), index);
            INT ie=e->getEdgeLocalIndex(edge);
            INT ne=femspace[0]->getTrialFunction(e->getIndex())->getNEdgeNode();
            k=e->getPolygon()+ne*ie;
            Matrix coord=femspace[0]->getTrialFunction(e->getIndex())->getNodeCoord();
            for (INT in=0; in<ne; in++){
                lambda[0]=coord[0][k+in];   lambda[1]=coord[1][k+in];
                x=space->mapping(e->getIndex(), lambda);
                pp[index[k+in]    ] =BoundaryVal[bp->getNVertex()+j*(Nn-2)+in];
                pp[index[k+in]+dof] =BoundaryVal[NboundaryNodes+bp->getNVertex()+j*(Nn-2)+in];
            }
        }
    }
    (*RHS[0])=(*RHS[0])-(*SMGM[0])*pp;
    for (i=0; i<nb; i++){
        BoundaryPatch *bp=grid->getBoundaryPatch(i);
        for (j=0; j<bp->getNVertex(); j++){
            Vertex *vertex=bp->getVertex(j);
            INT ii=vertex->getIndex();
            for (INT jj=0; jj<2*dof; jj++){
                (*SMGM[0])(ii+1, jj+1)=0.0;
                (*SMGM[0])(jj+1, ii+1)=0.0;
                (*SMGM[0])(ii+1+dof, jj+1)=0.0;
                (*SMGM[0])(jj+1, ii+1+dof)=0.0;
            }
            (*SMGM[0])(ii+1, ii+1)=1.0;
            (*SMGM[0])(ii+1+dof, ii+1+dof)=1.0;
            (*RHS[0])[ii]=pp[ii];
            (*RHS[0])[ii+dof]=pp[ii+dof];
        }

        for (j=0; j<bp->getNEdge(); j++){
            Edge *edge=bp->getEdge(j);
            Element *e=edge->getNeighborElement(0);
            INT index[femspace[0]->degreeOfFreedom(e->getIndex())];
            femspace[0]->getGlobalIndex(e->getIndex(), index);
            INT ie=e->getEdgeLocalIndex(edge);
            INT ne=femspace[0]->getTrialFunction(e->getIndex())->getNEdgeNode();
            k=e->getPolygon()+ne*ie;
            for (INT in=0; in<ne; in++){
                for (INT jj=0; jj<2*dof; jj++){
                    (*SMGM[0])(index[k+in]+1, jj+1)=0.0;
                    (*SMGM[0])(jj+1, index[k+in]+1)=0.0;
                    (*SMGM[0])(index[k+in]+1+dof, jj+1)=0.0;
                    (*SMGM[0])(jj+1, index[k+in]+1+dof)=0.0;
                }
                (*SMGM[0])(index[k+in]+1, index[k+in]+1)=1.0;
                (*SMGM[0])(index[k+in]+1+dof, index[k+in]+1+dof)=1.0;
                (*RHS[0])[index[k+in]]=pp[index[k+in]];
                (*RHS[0])[index[k+in]+dof]=pp[index[k+in]+dof];
            }
        }
    }
}

// impose first order absorbing boundary condition
void SE_VariableCoefficientHELMHLOTZProblem::imposeFIRSTORDERABC(){
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid *grid=femspace[0]->getGrid2D();
    LAGRANGE_2D_SQUARE *pTrial=(LAGRANGE_2D_SQUARE*)femspace[0]->getTrialFunction(0);

    Vector lambda(2), x(2);
    INT i, j, k, j1, l;
    INT nc=grid->getNElement();
    INT de=pTrial->getNEdgeNode()+2;
    INT eledof=pTrial->degreeOfFreedom();
    Quadrature *edgequad=new Quadrature(INTERVAL, quadrature->getType());
    edgequad->permuteData(de);
    Matrix qp =edgequad->getPoints();
    DOUBLE *wts=edgequad->getWeights();
    INT Dof=space->degreeOfFreedom();
    INT INDEX[eledof], Eindex[de];
    BoundaryPatch *bp=grid->getBoundaryPatch(1);
    for (j=0; j<bp->getNEdge(); j++){
        Edge *edge=bp->getEdge(j);
        Element *e=edge->getNeighborElement(0);
        INT ic=e->getIndex();//get the element number. 
        //cout<<ic<<endl;
        INT ie=e->getEdgeLocalIndex(edge);
        femspace[0]->getGlobalIndex(ic, INDEX);
        pTrial->getEdgeNodeIndex(ie, Eindex);


        for (l=0; l<de; l++){
            lambda[0]=qp[0][de-l-1];            lambda[1]=1.0;
            //cout<<lambda<<endl;
            x=space->mapping(ic, lambda);
            Matrix jm=space->JM(ic, lambda);
            DOUBLE ja=sqrt(jm(1, 1)*jm(1, 1)+jm(1, 2)*jm(1, 2));

            DOUBLE tmp=  ja*wts[de-l-1];
            (*SMGM[0])(INDEX[Eindex[l]]+1,INDEX[Eindex[l]]+1+Dof)=(*SMGM[0])(INDEX[Eindex[l]]+1,INDEX[Eindex[l]]+1+Dof)-kn*tmp;
            (*SMGM[0])(INDEX[Eindex[l]]+1+Dof,INDEX[Eindex[l]]+1)=(*SMGM[0])(INDEX[Eindex[l]]+1+Dof,INDEX[Eindex[l]]+1)+kn*tmp;

        }

        for (j1=0; j1<de; j1++){
            lambda[0]=qp[0][de-j1-1];            lambda[1]=1.0;
            Matrix jm=femspace[0]->JM(ic, lambda);
            DOUBLE ja=sqrt(jm(1, 1)*jm(1, 1)+jm(1, 2)*jm(1, 2));
            x=space->mapping(ic, lambda);
            (*RHS[0])[INDEX[Eindex[j1]]    ]=(*RHS[0])[INDEX[Eindex[j1]]    ]-coefficient_ptr[7]->d(x)*wts[de-j1-1]*ja;
            (*RHS[0])[INDEX[Eindex[j1]]+Dof]=(*RHS[0])[INDEX[Eindex[j1]]+Dof]-coefficient_ptr[8]->d(x)*wts[de-j1-1]*ja;
        }
    }
    delete edgequad;
}




//impose exact non-reflecting boundary condition
void SE_VariableCoefficientHELMHLOTZProblem::imposeNRBCBoundaryCondition(){
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid *grid=femspace[0]->getGrid2D();
    LAGRANGE_2D_SQUARE *pTrial=(LAGRANGE_2D_SQUARE*)femspace[0]->getTrialFunction(0);

    INT i, j, jj, k, j1, l;
    INT de=pTrial->getNEdgeNode()+2;
    INT ne=grid->getNEdge();
    INT eledof=pTrial->degreeOfFreedom();
    INT Dof=space->degreeOfFreedom();

    Quadrature *edgequad=new Quadrature(INTERVAL, quadrature->getType());
    edgequad->permuteData(de);
    Matrix qp =edgequad->getPoints();
    DOUBLE *wts=edgequad->getWeights();

    INT  index[de],  index1[de], INDEX[eledof], INDEX1[eledof];
    Complex DH[2*nFourierMode+1];
    Vector x1(2), x2(2), x(2), lambda(2), MoveVector(2);
    DOUBLE r1, theta1, r2, theta2;
    MoveVector=space->getMoveVector();

/*Compute \frac{\partial{H_1}}{H_1}*/ 
    DH[nFourierMode]=Complex(-gsl_sf_bessel_J1(kn*R2), -gsl_sf_bessel_Y1(kn*R2))/Complex(gsl_sf_bessel_J0(kn*R2), gsl_sf_bessel_Y0(kn*R2));
    for (k=1; k<=nFourierMode; k++){
        DH[nFourierMode+k]=1.0*(kn*R2)/(1.0*(k-1)-(kn*R2)*DH[nFourierMode+k-1])-1.0*k/(kn*R2);
        DH[nFourierMode-k]=DH[nFourierMode+k];
    }
    for (k=1; k<2*nFourierMode+1; k++){
        DH[k]=(-kn)*DH[k];
    }
    DOUBLE pi=4.0*atan(1.0);

    BoundaryPatch *bp=grid->getBoundaryPatch(1);
    CMatrix TMat[bp->getNEdge()];
    for (j=0; j<bp->getNEdge(); j++){
        Edge *edge=bp->getEdge(j);
        Element *e=edge->getNeighborElement(0);
        INT ic=e->getIndex();//get the element number.
        INT ie=e->getEdgeLocalIndex(edge);
        femspace[0]->getGlobalIndex(ic, INDEX);
        pTrial->getEdgeNodeIndex(ie, index);
        x1=e->getVertex(3)->getCoord();  x2=e->getVertex(2)->getCoord();

        cartTopolar(x1[0]-MoveVector[0], x1[1]-MoveVector[1], r1, theta1);
        cartTopolar(x2[0]-MoveVector[0], x2[1]-MoveVector[1], r2, theta2);
        TMat[j]=computeIntCoefToFCoef(theta1, theta2);
    }
    
    INT  Eindex[de];
    for (j=0; j<bp->getNEdge(); j++){
        Edge *edge=bp->getEdge(j);
        Element *e=edge->getNeighborElement(0);
        INT ic=e->getIndex();//get the element number. 
        INT ie=e->getEdgeLocalIndex(edge);
        femspace[0]->getGlobalIndex(ic, INDEX);
        pTrial->getEdgeNodeIndex(ie, Eindex);

        for (l=0; l<de; l++){
            lambda[0]=qp[0][de-l-1];            lambda[1]=1.0;
            x=space->mapping(ic, lambda);
            Matrix jm=space->JM(ic, lambda);
            DOUBLE ja=sqrt(jm(1, 1)*jm(1, 1)+jm(1, 2)*jm(1, 2));
            DOUBLE tmp=  ja*wts[de-l-1];
            (*SMGM[0])(INDEX[Eindex[l]]+1,INDEX[Eindex[l]]+1+Dof)=(*SMGM[0])(INDEX[Eindex[l]]+1,INDEX[Eindex[l]]+1+Dof)-kn*tmp;
            (*SMGM[0])(INDEX[Eindex[l]]+1+Dof,INDEX[Eindex[l]]+1)=(*SMGM[0])(INDEX[Eindex[l]]+1+Dof,INDEX[Eindex[l]]+1)+kn*tmp;
        }

        for (j1=0; j1<de; j1++){
            lambda[0]=qp[0][de-j1-1];            lambda[1]=1.0;
            Matrix jm=femspace[0]->JM(ic, lambda);
            DOUBLE ja=sqrt(jm(1, 1)*jm(1, 1)+jm(1, 2)*jm(1, 2));
            x=space->mapping(ic, lambda);
            (*RHS[0])[INDEX[Eindex[j1]]    ]=(*RHS[0])[INDEX[Eindex[j1]]    ]-coefficient_ptr[7]->d(x)*wts[de-j1-1]*ja;
            (*RHS[0])[INDEX[Eindex[j1]]+Dof]=(*RHS[0])[INDEX[Eindex[j1]]+Dof]-coefficient_ptr[8]->d(x)*wts[de-j1-1]*ja;
        }
    }
    delete edgequad;
}

void SE_VariableCoefficientHELMHLOTZProblem::solve(){
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    INT Dof=femspace[0]->degreeOfFreedom();
    setNSolution(2);
    setNRHS(1);
    for (int i=0; i<nSolution; i++)
        solution[i]=new Vector(2*Dof);
    assemble();
    SMGM[0]->restoreBuffer();
    computeRHS();             // compute right hand side
    imposeBoundaryCondition(1);// impose boundary condition
    imposeNRBCBoundaryCondition();// impose NRBC boundary condition
    Vector v(2*Dof);
    v=0.0;
    int max_iter=50000;
    DOUBLE tol=1.0e-14;
   
    UMFPACK_INTERFACE interface;
    interface.umfpack_di_solve(SMGM[0], RHS[0], &v);

    for (INT j=0; j<Dof; j++){
        (*solution[0])[j]=v[j];
        (*solution[1])[j]=v[j+Dof]; 
    }
}

void SE_VariableCoefficientHELMHLOTZProblem::getBoundaryInf(){
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid *grid=femspace[0]->getGrid2D();
    LAGRANGE_2D_SQUARE * psf=(LAGRANGE_2D_SQUARE*)femspace[0]->getTestFunction(0);
    BoundaryPatch *bp=grid->getBoundaryPatch(0); //Get boundary of scatterer !-)
    Nn=0;
    NboundaryNodes=0;
    for(INT i=0;i<bp->getNEdge();i++){
        Edge *edge=bp->getEdge(i);
        Element *e=edge->getNeighborElement(0);
        Nn=femspace[0]->getTrialFunction(e->getIndex())->getNEdgeNode();
        NboundaryNodes+=Nn;
    }
    NboundaryNodes+=bp->getNVertex();
    Nn+=2;
}//!-)



void SE_VariableCoefficientHELMHLOTZProblem::getBoundaryRHS(){
    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid *grid=femspace[0]->getGrid2D();
    BoundaryPatch *bp=grid->getBoundaryPatch(0);
    Quadrature *edgequad=new Quadrature(INTERVAL, quadrature->getType());
    edgequad->permuteData(Nn);
    INT ni=Nn-2;
    Matrix qp=edgequad->getPoints();
    BoundaryRHS.setDim(2*NboundaryNodes);
    Vector x(2),lambda(2);
    lambda[0]=qp[0][Nn-1];lambda[1]=-1.0;
    for(INT ic=0;ic<bp->getNEdge();ic++){
        Vertex *vertex=bp->getVertex(ic);
        x=vertex->getCoord();
        BoundaryRHS[ic               ]=coefficient_ptr[1]->d(x);//Points on Vertex!-)
        BoundaryRHS[ic+NboundaryNodes]=coefficient_ptr[2]->d(x);
        for(INT jc=1;jc<Nn-1;jc++){
            lambda[0]=qp[0][jc];
            x=space->mapping(ic,lambda);
            BoundaryRHS[bp->getNVertex()+jc-1+ic*ni               ]=coefficient_ptr[1]->d(x);
            BoundaryRHS[bp->getNVertex()+jc-1+ic*ni+NboundaryNodes]=coefficient_ptr[2]->d(x);
        }
    }   
}//!-)



void SE_VariableCoefficientHELMHLOTZProblem::getbpcoord(Matrix &coord){
	coord.setDim(NboundaryNodes,2);
	SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid *grid=femspace[0]->getGrid2D();
    INT i, j, k;
    Vector pp(2*femspace[0]->degreeOfFreedom());
    Vector lambda(2), x(2);
    INT dof=space->degreeOfFreedom();
    for (i=0; i<1; i++){
        BoundaryPatch *bp=grid->getBoundaryPatch(i);
        for (j=0; j<bp->getNVertex(); j++){
            Vertex *vertex=bp->getVertex(j);		    // Nodes on vertexes
            x=vertex->getCoord();//cout<<x<<endl;
            coord[j][0]=x[0];  
            coord[j][1]=x[1];
        }

        for (j=0; j<bp->getNEdge(); j++){               // Nodes on edges
            Edge *edge=bp->getEdge(j);
            Element *e=edge->getNeighborElement(0);
            INT index[femspace[0]->degreeOfFreedom(e->getIndex())];
            femspace[0]->getGlobalIndex(e->getIndex(), index);
            INT ie=e->getEdgeLocalIndex(edge);
            INT ne=femspace[0]->getTrialFunction(e->getIndex())->getNEdgeNode();
            k=e->getPolygon()+ne*ie;
            Matrix Coord=femspace[0]->getTrialFunction(e->getIndex())->getNodeCoord();
            for (INT in=0; in<ne; in++){
                lambda[0]=Coord[0][k+in];	lambda[1]=Coord[1][k+in];
                x=space->mapping(e->getIndex(), lambda);
                //cout<<x<<"		"<<j<<endl;
                coord[e->getPolygon()+in+j*ne][0]=x[0];
                coord[e->getPolygon()+in+j*ne][1]=x[1];
            }
        }
    }
    
//    SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
//    Grid *grid=femspace[0]->getGrid2D();
//    BoundaryPatch *bp=grid->getBoundaryPatch(0);
//    Quadrature *edgequad=new Quadrature(INTERVAL, quadrature->getType());
//    edgequad->permuteData(Nn);
//    coord.setDim(NboundaryNodes,2);
//    INT ni=Nn-2;
//    Matrix qp=edgequad->getPoints();
//    BoundaryRHS.setDim(2*NboundaryNodes);
//    Vector x(2),lambda(2);
//    lambda[0]=qp[0][Nn-1];lambda[1]=-1.0;
//    for(INT ic=0;ic<bp->getNEdge();ic++){
//        Vertex *vertex=bp->getVertex(ic);
//        x=vertex->getCoord();
//        coord[ic][0]=x[0];//Points on Vertex!-)
//        coord[ic][1]=x[1];
//        for(INT jc=1;jc<Nn-1;jc++){
//            lambda[0]=qp[0][jc];
//            x=space->mapping(ic,lambda);
//            coord[bp->getNVertex()+jc-1+ic*ni][0]=x[0];
//            coord[bp->getNVertex()+jc-1+ic*ni][1]=x[1];
//        }
//    }   
}



void SE_VariableCoefficientHELMHLOTZProblem::evalArtificialBoundaryValue(){

	SpectralElementSpace* space=(SpectralElementSpace*)femspace[0];
    Grid *grid=femspace[0]->getGrid2D();
    LAGRANGE_2D_SQUARE *pTrial=(LAGRANGE_2D_SQUARE*)femspace[0]->getTrialFunction(0);

    Vector lambda(2), x(2);
    INT i, j, k, j1, l;
    INT nc=grid->getNElement();
    INT de=pTrial->getNEdgeNode()+2;
    INT eledof=pTrial->degreeOfFreedom();
    (*ValueonAB).setDim(2*de*nc);
    Quadrature *edgequad=new Quadrature(INTERVAL, quadrature->getType());
    edgequad->permuteData(de);
    Matrix qp =edgequad->getPoints();
    DOUBLE *wts=edgequad->getWeights();
    INT Dof=space->degreeOfFreedom();
    INT INDEX[eledof], Eindex[de];
    BoundaryPatch *bp=grid->getBoundaryPatch(1);

    for (j=0; j<bp->getNEdge(); j++){
        Edge *edge=bp->getEdge(j);
        Element *e=edge->getNeighborElement(0);
        INT ic=e->getIndex();//get the element number. 
        INT ie=e->getEdgeLocalIndex(edge);
        femspace[0]->getGlobalIndex(ic, INDEX);
        pTrial->getEdgeNodeIndex(ie, Eindex);
        for(INT i=0;i<de;i++){
          lambda[0]=qp[0][i];lambda[1]=1.0;
           x=space->mapping(j,lambda);
          (*ValueonAB)[de-1-i+j*de      ]=(*(solution[0]))[INDEX[Eindex[i]]];
          (*ValueonAB)[de-1-i+j*de+de*nc]=(*(solution[1]))[INDEX[Eindex[i]]];
        }
      }
    
}
