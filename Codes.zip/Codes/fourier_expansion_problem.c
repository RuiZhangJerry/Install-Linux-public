#include "fourier_expansion_problem.h"

DOUBLE testfunction ::d(Vector x){
	return sin(x[0]+x[1]);
	//return 1.0;
	//return x[0];
	//return cos(x[0]+x[1]);
}

Complex testfunction ::c(Vector x){
    DOUBLE r=PropVec*x;
    Complex c(cos(r), sin(r));
    return c;

}


// *****************************************************************
//   compute v_{in} such that:
//       l_i(\xi)=\sum\limits_{n=0}^Nv_{in}P_n(\xi)  N=polyDeg
//   V=[v_{i0}, v_{i1}, \cdots, v_{iN}]
//
// *****************************************************************
Vector Fourier_Expansion::LagrangeLobattoToLegendre(INT deg, INT index){
    Quadrature *quad=new Quadrature(INTERVAL, GAUSS_LOBATTAO_QUADRATURE);
    quad->permuteData(deg+1);

    Matrix qp =quad->getPoints();
    DOUBLE *wts=quad->getWeights();
    INT np=quad->getNPoints();

    Vector V(deg+1);
    V=0.0;

    for (int i=0; i<deg+1; i++){
        DOUBLE tmp=0.0;
        for(INT kk=0; kk<np; kk++){
            DOUBLE lambda=qp[0][kk];
            DOUBLE Legr1=gsl_sf_legendre_Pl(i, lambda);
            tmp+=Legr1*Legr1*wts[kk];
        }
        V[i]=gsl_sf_legendre_Pl(i, qp[0][index])*wts[index]/tmp;
    }
    delete quad;
    return V;
}

// *****************************************************************
//   compute v_{in} such that:
//       l_i(\xi)=\sum\limits_{n=0}^Nv_{in}J_n^{(\alpha,\beta)}(\xi)
//       N=polyDeg
//   V=[v_{i0}, v_{i1}, \cdots, v_{iN}]
//
// *****************************************************************
Vector Fourier_Expansion::LagrangeLobattoToJacobi(INT deg, INT index, DOUBLE alpha, DOUBLE beta){

    DOUBLE qp[deg+1];
    DOUBLE wts[deg+1];
    INT np=deg+1;
    Quadrature::JacobiGauss(np, alpha, beta, qp, wts);
    Vector V(deg+1);
    LAGRANGEShapeFunction trial(deg);
    DOUBLE glp[deg+1], w[deg+1];
    Quadrature::LegendreGaussLobatto(deg+1, glp, w);
    Vector coord(deg+1);
    coord=glp;
    trial.setNodePointCoord(coord);
    trial.computeCoefficient();

    for (int i=0; i<deg+1; i++){
        DOUBLE tmp=0.0;
        DOUBLE integral=0.0;
        JacobiPoly poly(i, alpha, beta);
        for(INT kk=0; kk<np; kk++){
            Vector lambda(1);
            lambda[0]=qp[kk];
            DOUBLE Legr1=poly(lambda[0]);
            tmp+=Legr1*Legr1*wts[kk];

            Matrix val;
            trial.phi(lambda, val);
            integral+=val[0][index]*Legr1*wts[kk];
        }
        V[i]=integral/tmp;
    }
    return V;
}


// *****************************************************************
//   compute Interpolation coefficents to Fourier coefficient transform
//   matrix K=(k_nj), where
//     k_{nj}=int_{\theta_1}^{\theta_2}l_i(\xi)e^{-in\theta}d\theta
//   Noting that a factor 1/(2\pi) is missing for fourier transform
// *****************************************************************

void Fourier_Expansion::computeIntCoefToFCoef(INT ic){
    DOUBLE pi=4.0*atan(1.0);
    DOUBLE r0,r1,theta0,theta1;
    DOUBLE* x0=meshgrid->getBoundaryPatch(1)->getEdge(ic)->getVertex(0)->getCoord();
    DOUBLE* x1=meshgrid->getBoundaryPatch(1)->getEdge(ic)->getVertex(1)->getCoord();//Note that COPY VERTEX!
    Vector v0(2), v1(2);
    v0[0]=x0[0];  v0[1]=x0[1];
    v1[0]=x1[0];  v1[1]=x1[1];
    v0[0]=v0[0]-centerpoint[0]; v1[0]=v1[0]-centerpoint[0];
    v0[1]=v0[1]-centerpoint[1]; v1[1]=v1[1]-centerpoint[1];
    cartTopolar(v0[0],v0[1],r0,theta0);
    cartTopolar(v1[0],v1[1],r1,theta1);
    if(theta0-theta1<0)
        theta0=theta0+2.0*pi;
    DOUBLE J=(theta0-theta1)/2.0;
    DOUBLE alpha=(theta0+theta1)/2.0;
    for (INT j=0; j<polyDeg+1; j++){
        Vector vj=LagrangeLobattoToLegendre(polyDeg, j);
        //DOUBLE J=pi/nPatch;

        IntCoefToFCoef[nFourierMode][ic*(polyDeg+1)+j]=2.0*vj[0]*J;
        for (INT k=1; k<=nFourierMode; k++){
            //DOUBLE alpha=(2.0*ic+1.0)*pi/nPatch;
            //DOUBLE alpha=(ic+1.0)*pi/2.0;
            //DOUBLE alpha=theta0;
            Complex ex;
            ex.rp()= cos(alpha*k);
            ex.ip()=-sin(alpha*k);
            Complex tmp=0.0;
            for(INT n=0; n<polyDeg+1; n++){
                DOUBLE jn=gsl_sf_bessel_jl(n, J*k);
                Complex ni;
                ni.rp()=cos(pi*n/2.0);
                ni.ip()=sin(pi*n/2.0);
            
                tmp=tmp+vj[n]*jn/ni;
            }
            IntCoefToFCoef[nFourierMode+k][ic*(polyDeg+1)+j]=2.0*J*ex*tmp;
        }
        for (INT k=1; k<=nFourierMode; k++)
            IntCoefToFCoef[nFourierMode-k][ic*(polyDeg+1)+j]=IntCoefToFCoef[nFourierMode+k][ic*(polyDeg+1)+j].conjugate();
    }
}



void Fourier_Expansion::computeFourierCplx_disc(){
    for(INT ii=0;ii<2*nFourierMode+1;ii++){
        FourierCoef[ii]=0.0;
    }

    int i, j, n, nn;
    Vector x(2);
    Quadrature *quad=new Quadrature(INTERVAL, GAUSS_LOBATTAO_QUADRATURE);
    quad->permuteData(polyDeg+1);
    DOUBLE pi=4.0*atan(1.0);
    Matrix qp =quad->getPoints();
    Complex intpc[polyDeg+1];
    for (i=0; i<nPatch; i++){
        for (j=0; j<polyDeg+1; j++){      // obtain interpolant coefficients
            DOUBLE xhat=qp[0][j];
            (intpc[j]).rp()=(*nodesval)[j+i*(polyDeg+1)          ];
            (intpc[j]).ip()=(*nodesval)[j+i*(polyDeg+1)+nPatch*(polyDeg+1)];
        }

        nn=i*(polyDeg+1);
        for (n=0; n<2*nFourierMode+1; n++){
            for (j=0; j<polyDeg+1; j++){     // transform to Fourier coefficients
                FourierCoef[n]=FourierCoef[n]+IntCoefToFCoef[n][nn+j]*intpc[j];
            }
        }
    }
    for (n=0; n<2*nFourierMode+1; n++){
        FourierCoef[n]=FourierCoef[n]/(2.0*pi);
    }   // add missing factor 2\pi
        
    
    delete quad;
}
