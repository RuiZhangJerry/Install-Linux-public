/********************************************************************
*         HELMHLOTZ equations with varialbe coefficient
*         SPECTRAL GALERKIN method
*********************************************************************/
#include "SpectralElementSpace.h"
#include "FEMProblem.h"
#include "ufunc.h"
#include "shapeFunctions.h"
#include <gsl/gsl_sf_legendre.h>
#include <gsl/gsl_sf_bessel.h>
#include "cmatrix.h"
#include "umfpack_interface.h"
#define PI 4.0*atan(1.0)
class ScalarCoefficient : public Coefficient{

public:
	virtual DOUBLE d(Vector x);
};

class ReBoundaryCondition : public Coefficient{
	DOUBLE kn;
public:
	ReBoundaryCondition(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);

};

class ImBoundaryCondition : public Coefficient{
	DOUBLE kn;
public:
	ImBoundaryCondition(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);

};

class ReRHSFunc : public Coefficient{
	DOUBLE kn;
public:
	ReRHSFunc(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);
};

class ImRHSFunc : public Coefficient{
	DOUBLE kn;
public:
	ImRHSFunc(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);
};
class ReExactSolution : public Coefficient{
	DOUBLE kn;
public:
	ReExactSolution(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);
};

class ImExactSolution : public Coefficient{
	DOUBLE kn;
public:
	ImExactSolution(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);
};

class ReFirstorderg : public Coefficient{
	DOUBLE kn;
public:
	ReFirstorderg(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);
};

class ImFirstorderg : public Coefficient{
	DOUBLE kn;
public:
	ImFirstorderg(DOUBLE a){
		kn=a;
	}
	virtual DOUBLE d(Vector x);
};

class ReNRBCg : public Coefficient{
    DOUBLE kn;
public:
    ReNRBCg(DOUBLE a){
        kn=a;
    }
    virtual DOUBLE d(Vector x);
};

class ImNRBCg : public Coefficient{
    DOUBLE kn;
public:
    ImNRBCg(DOUBLE a){
        kn=a;
    }
    virtual DOUBLE d(Vector x);
};

// class ExactSolution : public Coefficient{
	// DOUBLE alpha;
// public:
	// ExactSolution(DOUBLE a){
		// alpha=a;
	// }
	// virtual DOUBLE d(Vector x);
    // virtual Vector v(Vector x);
// };



class SE_VariableCoefficientHELMHLOTZProblem : public FEMProblem{
	DOUBLE kn;
	int    nFourierMode;
	DOUBLE R1;
	DOUBLE R2;
	int    M;
	Complex *H;
	Complex *H1;
	Complex **FourierA;
	Complex **FourierB;
	Complex *FourierCoef;
	Vector* ValueonAB;

	INT NboundaryNodes;
	INT Nn;
	
	Vector BoundaryVal; 
	Vector BoundaryRHS;

	Matrix* CooronAB;
	//Vector* ValueonAB;
	
	Vector ExtBoundaryVal;

    Vector LagrangeLobattoToLegendre(INT deg, INT index);

public:
	SE_VariableCoefficientHELMHLOTZProblem(FEMSpace *fs, Quadrature *quad) : FEMProblem(fs, quad){
        kn   =10.0;
		//HDSE_tau=1.0;
        nFourierMode=55;
		R1=1.0;
		R2=1.0;

		H=new Complex [2*nFourierMode+2];
		H1=new Complex [2*nFourierMode+2];
        coefficient_ptr=new Coefficient *[11];
		coefficient_ptr[0]=new ScalarCoefficient;
		coefficient_ptr[1]=new ReBoundaryCondition(kn);
		coefficient_ptr[2]=new ImBoundaryCondition(kn);
		coefficient_ptr[3]=new ReRHSFunc(kn);
		coefficient_ptr[4]=new ImRHSFunc(kn);
		coefficient_ptr[5]=new ReExactSolution(kn);
		coefficient_ptr[6]=new ImExactSolution(kn);
		coefficient_ptr[7]=new ReFirstorderg(kn);
		coefficient_ptr[8]=new ImFirstorderg(kn);
        coefficient_ptr[9]=new ReNRBCg(kn);
        coefficient_ptr[10]=new ImNRBCg(kn);
        ValueonAB=new Vector;
	}

	~SE_VariableCoefficientHELMHLOTZProblem(){
		delete coefficient_ptr[0];
		delete coefficient_ptr[1];
		delete coefficient_ptr[2];
		delete coefficient_ptr[3];
		delete coefficient_ptr[4];
		delete coefficient_ptr[5];
		delete coefficient_ptr[6];
		delete coefficient_ptr[7];
		delete coefficient_ptr[8];
        delete coefficient_ptr[9];
        delete coefficient_ptr[10];
	}
	Coefficient *getReExactSolution(){ return coefficient_ptr[5];}
	Coefficient *getImExactSolution(){ return coefficient_ptr[6];}


    CMatrix computeIntCoefToFCoef(DOUBLE theta_1, DOUBLE theta_2);

	virtual void computeRHS();
	virtual void computeLocalMatrices(INT i);
	virtual void assemble();
	virtual void imposeBoundaryCondition(int nb);
	

	//virtual void imposeBoundaryCondition(int nb);
	virtual void imposeNRBCBoundaryCondition();
	virtual void imposeFIRSTORDERABC();

	virtual void solve();
	//virtual void solve();

	/************************
	        A general interpolation, do not 
	        depende on the node index!-)
	        ************************/
			void Interpolant(INT ic,Vector lambda, Vector BVP, DOUBLE &v);
			
			/***********************
			Get boundary information, including 
			number of boundary nodes, the number 
			of nodes on each side !-)
			***********************/
			void getBoundaryInf();
			
			void getExtBoundaryVal();
			Vector getEBV(){
				return ExtBoundaryVal;
			}

			Complex evalABVal(Vector x);
			/**********************
			Get boundary values from the solution.
			In this codes and libary designed by 
			Mr. B. Wang the order of nodes is as following:
			Solution=(Vertex_0,...,Vertex_NVertex, Innerpoint_0,..., Innerpoints_NEdge),where
			NEdge notes the number of edges of scatterrer, NVertex means the number of vertex,
			And recalling that solution is a vector pointer!-)
			**********************/
		
			Vector getBV(){
				return BoundaryVal;
			}
	        void getBoundaryRHS();
	        Vector getRV(){
	        	return BoundaryRHS;
			}
			INT getNB(){
				return NboundaryNodes;
			}
			void setBoundaryVal(Vector BV){
				//getBoundaryInf();
				BoundaryVal.setDim(2*getNB());
				BoundaryVal=BV;
			}
			void getbpcoord(Matrix &coord);

	void evalArtificialBoundaryValue();
	PVector getArtificialBoundaryValue(){
		return ValueonAB;
	}

         CVector computFourier(Vector &ReVec, Vector &ImVec);

};

typedef SE_VariableCoefficientHELMHLOTZProblem SEVCEP;
typedef SE_VariableCoefficientHELMHLOTZProblem * PSEVCEP;
