#ifndef FOURIER_EXPANSION_PROBLEM_H
#define FOURIER_EXPANSION_PROBLEM_H

#include <iostream>
#include <gsl/gsl_sf_legendre.h>
#include <gsl/gsl_sf_bessel.h>
#include "matrix.h"
#include "quadrature.h"
#include "shapeFunctions.h"
#include "complex.h" 
#include "coefficients.h"
#include "polynomial.h"

#include "SpectralElementSpace.h"


class testfunction : public Coefficient{
    Vector PropVec;
public:
    testfunction(Vector kv){
        PropVec=kv;
	}
    virtual  DOUBLE d(Vector x);
    virtual Complex c(Vector x);
};

class Fourier_Expansion{
    INT polyDeg, nPatch, nFourierMode;
    Complex **IntCoefToFCoef;
    Complex *FourierCoef;
    PVector nodesval;
    Coefficient* fun;
    Grid* meshgrid;
    Vector centerpoint;
public:
    Fourier_Expansion(Grid *grid,INT deg,INT nF){
        meshgrid=grid;

        polyDeg=deg;
        nPatch=grid->getBoundaryPatch(1)->getNEdge( );
        centerpoint.setDim(2);centerpoint=0.0;
        for(INT i=0;i<grid->getBoundaryPatch(1)->getNVertex();i++){
            centerpoint[0]+=(meshgrid->getBoundaryPatch(1)->getVertex(i)->getCoord())[0];
            centerpoint[1]+=(meshgrid->getBoundaryPatch(1)->getVertex(i)->getCoord())[1];
        }
        centerpoint[0]=centerpoint[0]/nPatch;
        centerpoint[1]=centerpoint[1]/nPatch;

        nFourierMode=nF;
        IntCoefToFCoef=new Complex *[2*nFourierMode+1];
        FourierCoef=new Complex[2*nFourierMode+1];
        nodesval=new Vector;
        for (INT i=0; i<2*nFourierMode+1; i++){
            IntCoefToFCoef[i]=new Complex[nPatch*(polyDeg+1)];
            FourierCoef[i]=0.0;
        }

        for (int i=0; i<nPatch; i++){
            computeIntCoefToFCoef(i);
        }
    }


    Fourier_Expansion(INT N, INT deg, INT nF){
        nPatch=N;
        polyDeg=deg;
        nFourierMode=nF;
        IntCoefToFCoef=new Complex *[2*nFourierMode+1];
        FourierCoef=new Complex[2*nFourierMode+1];
        nodesval=new Vector;

        for (INT i=0; i<2*nFourierMode+1; i++){
            IntCoefToFCoef[i]=new Complex[N*(polyDeg+1)];
            FourierCoef[i]=0.0;
        }

        for (int i=0; i<N; i++){
            computeIntCoefToFCoef(i);
        }
    }

    Fourier_Expansion(Coefficient* f,INT N, INT deg, INT nF){
        fun=f;
        nPatch=N;
        polyDeg=deg;
        nFourierMode=nF;
        IntCoefToFCoef=new Complex *[2*nFourierMode+1];
        FourierCoef=new Complex[2*nFourierMode+1];
        nodesval=new Vector;

        for (INT i=0; i<2*nFourierMode+1; i++){
            IntCoefToFCoef[i]=new Complex[N*(polyDeg+1)];
            FourierCoef[i]=0.0;
        }

        for (int i=0; i<N; i++){
            computeIntCoefToFCoef(i);
        }
    }

    ~Fourier_Expansion(){
		
        for (INT i=0; i<2*nFourierMode+1; i++){
                    delete []IntCoefToFCoef[i];
			}
            delete []IntCoefToFCoef;
        delete []FourierCoef;
    }

    INT      getNFourierMode(){     return nFourierMode;  }
    Complex *getFourierCoefficients(){  return FourierCoef; }

    Vector LagrangeLobattoToLegendre(INT deg, INT index);
    Vector LagrangeLobattoToJacobi(INT deg, INT index, DOUBLE alpha, DOUBLE beta);
    void   computeIntCoefToFCoef(INT ic);

    void   setnodesval(PVector val){
        nodesval=val;
    }
    void   computeFourierCplx_disc();
};

#endif // FOURIER_EXPANSION_PROBLEM_H
